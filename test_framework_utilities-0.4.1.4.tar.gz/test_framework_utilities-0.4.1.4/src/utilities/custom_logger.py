import logging
import os
from root_dir import get_root_dir


class CustomLogger(logging.getLoggerClass()):

    def __init__(self, name: str, log_dir=None) -> None:
        super().__init__(name)
        self.setLevel(logging.DEBUG)

        self.file_handler = None
        self._add_file_handler(name, log_dir)

    def _add_file_handler(self, name, log_dir):
        formatter = logging.Formatter('%(asctime)s.%(msecs)03d - %(levelname)s: %(message)s',
                                      datefmt="%d-%b-%Y %H:%M:%S")

        dir_path = os.path.join(get_root_dir(), log_dir)

        if not os.path.exists(dir_path):
            os.makedirs(dir_path)

        log_file = os.path.join(dir_path, name)

        self.file_handler = logging.FileHandler(log_file, mode='w')
        self.file_handler.setLevel(logging.DEBUG)
        self.file_handler.setFormatter(formatter)
        self.addHandler(self.file_handler)

    def has_file_handler(self):
        return len([h for h in self.handlers if type(h) == logging.FileHandler])

    def debug(self, msg, *args, **kwargs):
        super().debug(msg, *args, **kwargs)

    def info(self, msg, *args, **kwargs):
        super().info(msg, *args, **kwargs)

    def warning(self, msg, *args, **kwargs):
        super().warning(msg, *args, **kwargs)

    def error(self, msg, *args, **kwargs):
        super().error(msg, *args, **kwargs)

    def critical(self, msg, *args, **kwargs):
        super().critical(msg, *args, **kwargs)

    def exception(self, msg, *args, exc_info=True, **kwargs):
        super().exception(msg, *args, exc_info, **kwargs)
