import os
from xml.etree import ElementTree
from root_dir import get_root_dir

xml_directory = ""


def set_xml_directory(xml_path):
    global xml_directory
    xml_directory = xml_path


def get_data_from_xml(xml_path, node_name):
    root = ElementTree.parse(xml_path).getroot()
    return root.find(".//" + node_name).text


def get_node(name):
    xml_path = os.path.join(get_root_dir() + xml_directory)
    return get_data_from_xml(xml_path, name)
