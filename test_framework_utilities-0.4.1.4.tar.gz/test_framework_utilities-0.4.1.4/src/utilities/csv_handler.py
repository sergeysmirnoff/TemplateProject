import inspect
import allure
import pandas as pd

from utilities.custom_logger import CustomLogger


class CsvHandler:

    def __init__(self, logger: CustomLogger) -> None:
        self.logger = logger

    @allure.step("Verify extracted values")
    def compare_to_csv(self, expected_values: {}, expected_headers: [], csv_path, query, ignored_headers=None):
        """
        Compares the csv values to the expected values and headers to the expected headers.\n
        if headers won't match, the function won't continue to check for the values.\n
        :param expected_values: the expected values to find in the csv (dict).
        :param expected_headers: the expected headers to find in the csv (array).
        :param csv_path: the path to the csv (string).
        :param query: a query to parse the csv for the correct data. query should be in the form of pandas dataframe queries (string).
        :param ignored_headers: the headers the system should ignore.
        :return: an array with error messages or None if no error was found.
        """
        self.logger.info("{} - Comparing the CSV file values to the expected values".format(self.callers_names()))
        self.logger.info("{} - CSV file: \"{}\"\n\tExpected Values: \"{}\"\n\tExpected Headers: \"{}\"\n\tQuery: \"{}\"\n\tIgnored Headers: \"{}\""
                         .format(self.callers_names(), csv_path, expected_values, expected_headers, query, ignored_headers))
        if ignored_headers is None:
            ignored_headers = []
        rows, cols = self.csv_parser(csv_path)
        arr = self.check_headers_match(expected_headers, cols, ignored_headers)
        if len(arr) != 0:
            return arr
        df = self.query_csv(csv_path, query)
        if df.empty:
            self.logger.error("{} - DataFrame is empty, nothing matches the provided query")
            return "dataframe is empty - nothing matches the provided query"
        arr = self.check_df_values_match(df, expected_headers, expected_values, ignored_headers)
        if len(arr) != 0:
            return arr
        self.logger.info("{} - Returning \"None\", compare successful".format(self.callers_names()))
        return None

    @allure.step("Returns a given column values")
    def csv_column(self, col_name, csv_path="", df=None):
        self.logger.info("{} - Returning values of column \"{}\" from CSV file \"{}\"".format(self.callers_names(), col_name, csv_path))
        if df is None:
            df = pd.read_csv(csv_path)
        self.logger.info("{} - Column \"{}\" values are: \"[{}]\"".format(self.callers_names(), col_name, df[col_name]))
        return df[col_name]

    @allure.step("Check headers")
    def check_headers_match(self, expected_headers, actual_headers, ignored_headers: []):
        arr = []
        i = 0
        for header in actual_headers:
            if header not in ignored_headers:
                if header not in expected_headers:
                    arr.append("actual header ({}) isn't present in expected headers list".format(header))
            i = i + 1
        return arr

    @allure.step("Check DataFrame values")
    def check_df_values_match(self, df, expected_headers, expected_values, ignored_headers: []):
        arr = []
        i = 0
        k = 0
        while i < len(expected_headers):
            while k < df.shape[0]:
                if expected_headers[i] in ignored_headers:
                    i = i + 1
                df_value = str(df[expected_headers[i]][k])
                expected_value = expected_values.get(expected_headers[i])
                if df_value != expected_value:
                    k = k + 1
                    if k >= df.shape[0]:
                        arr.append("expected value ({}) doesn't match actual value ({}) at header ({})"
                                   .format(expected_value, df_value, expected_headers[i]))
                    i = 0
                else:
                    break
            i = i + 1
        return arr

    @allure.step("Query CSV file")
    def query_csv(self, filepath, query):
        """
        Queries a csv file.\n
        :param filepath: the path to the csv file.
        :param query: the query to parse the csv file.
        :return: pandas dataframe representing the queried csv file.
        """
        df = pd.read_csv(filepath)
        df = df.query(query)
        df.reset_index(drop=True, inplace=True)
        return df

    @allure.step("Get CSV rows and columns values")
    def csv_parser(self, file_path):
        data = pd.read_csv(file_path)
        columns = data.columns.values
        rows = data.values
        return rows, columns

    @allure.step("Parses dataframe by column name")
    def parse_dataframe_by_column(self, df, col_name, col_value):
        if col_value.isnumeric():
            col_value = int(col_value)
        df = df.loc[df[col_name] == col_value]
        df.reset_index(drop=True, inplace=True)
        return df

    @allure.step("Create Pandas DataFrame from CSV file")
    def create_dataframe_from_csv(self, file_path, col_name=None, col_value=None):
        self.logger.info("{} - Creating a Pandas DataFrame from CSV file: \"{}\"".format(self.callers_names(), file_path))
        df = pd.read_csv(file_path)
        if col_name is None:
            self.logger.info("{} - Columns are empty, returning an empty DataFrame")
            return df
        else:
            if col_value is None:
                raise TypeError
            else:
                return self.parse_dataframe_by_column(df, col_name, col_value)

    @allure.step("Remove unneeded columns from the Pandas DataFrame")
    def drop_unneeded_columns(self, df: pd.DataFrame, unneeded_columns: list[str]) -> pd.DataFrame:
        """
        Removes unneeded columns from a Pandas DataFrame, does so inplace.\n
        :param df: the DataFrame to manipulate.
        :param unneeded_columns: the columns to drop.
        :return: same DataFrame without the unneeded columns
        """
        self.logger.info("{} - Dropping unneeded columns \"[{}]\"".format(self.callers_names(), unneeded_columns))
        df.drop(columns=unneeded_columns, inplace=True)
        return df

    @allure.step("Create ignore headers list")
    def headers_to_ignore(self, start_index: int, end_index: int, column_name: str, *column_names: str) -> list[str]:
        """
        Creates a list of ignore names from repeating column name.\n
        :param start_index: the starting index (including).
        :param end_index: the end index (excluding).
        :param column_name: the column name.
        :param column_names: other repeating column name to be added (optional, variadic).
        :return: a list of Strings consisting of the column names to be ignored.
        """
        ignore_list = ["{column_name}_{idx}".format(column_name=column_name, idx=i) for i in range(start_index, end_index)]
        if column_names:
            for name in column_names:
                ignore_list.extend(["{column_name}_{idx}".format(column_name=name, idx=i) for i in range(start_index, end_index)])

        if len(ignore_list) > 0:
            self.logger.info("{} - Created ignore list with the headers: \"[{}]\"".format(self.callers_names(), ignore_list))
        return ignore_list

    def callers_names(self) -> str:
        """
        Returns the caller class and method names.\n
        """
        inspector = inspect.stack()[1][0]
        caller_class = inspector.f_locals["self"].__class__.__name__
        caller_method = inspector.f_code.co_name
        caller_line = inspect.currentframe().f_back.f_lineno
        return "{}::{}::{}".format(caller_class, caller_method, caller_line)
