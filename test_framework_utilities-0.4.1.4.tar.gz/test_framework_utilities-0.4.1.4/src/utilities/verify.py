import os
import allure
import pytest
import collections as COL

from pytest_check import check_methods as check


class Verify:

    def __init__(self, sd):
        self.sd = sd

    @allure.step("Verify values match")
    def verify_values_match(self, expected: str, actual: str, method_name: str = None):
        if method_name is None:
            method_name = self.sd.callers_names()
        self.sd.logger.info("{} - Asserting values equal:\n\tExpected: \"{}\"\n\tActual: \"{}\"\n\tAt: \"{}\""
                            .format(method_name, expected, actual, method_name))
        try:
            assert expected == actual, "Verification mismatch from '{}' at '{}':\nExpected: {}\nActual: {}"\
                .format(self.verify_values_match.__name__, method_name, expected, actual)
            self.sd.logger.info("{} - Asserting equality success".format(method_name))
        except AssertionError as e:
            self.sd.logger.error("{} - Assertion failed, values not equal:\n\tExpected: \"{}\"\n\tActual: \"{}\"\n\tAt: \"{}\""
                                 .format(method_name, expected, actual, method_name))
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    @allure.step("Verify values doesn't match")
    def verify_value_not_matches(self, expected: str, actual: str, method_name: str = None):
        if method_name is None:
            method_name = self.sd.callers_names()
        self.sd.logger.info("{} - Asserting values not equal:\n\tExpected: \"{}\"\n\tActual: \"{}\"\n\tAt: \"{}\""
                            .format(method_name, expected, actual, method_name))
        try:
            assert not expected == actual, "verify_value_not_matches - values match at method: " + method_name
            self.sd.logger.info("{} - Asserting inequality success".format(method_name))
        except AssertionError as e:
            self.sd.logger.error("{} - Assertion failed, values equal:\n\tExpected: \"{}\"\n\tActual: \"{}\"\n\tAt: \"{}\""
                                 .format(self.sd.callers_names(), expected, actual, method_name))
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    @allure.step("Verify String is contained in another string")
    def verify_string_in_string(self, s1: str, s2: str, name: str = None):
        if name is None:
            name = self.sd.callers_names()
        self.sd.logger.info("{} - Asserting string: \"{}\" is contained in string: \"{}\"".format(name, s1, s2))
        try:
            assert s1 in s2, "first string isn't part of second string"
            self.sd.logger.info("{} - Assertion string in string success".format(name))
        except AssertionError as e:
            self.sd.logger.error("{} - Assertion string in string failure, string \"{}\" is not contained in string \"{}\""
                                 .format(name, s1, s2))
            self.sd.screenshot(name)
            pytest.fail(str(e))

    @allure.step("Verify string list contained in another string list")
    def verify_string_array_in_string_array(self, strings_a: [], strings_b: [], method_name: str = None):
        if method_name is None:
            method_name = self.sd.callers_names()
        self.sd.logger.info("{} - Asserting all strings from: \"{}\" are contained in: \"{}\"".format(method_name, strings_a, strings_b))
        for string in strings_a:
            try:
                assert string in strings_b, "verify_string_in_string - string \"{}\" isn't in list \"{}\"".format(string, strings_b)
                self.sd.logger.info("{} - Assertion string: \"{}\" in string list \"{}\" success".format(method_name, string, strings_b))
            except AssertionError as e:
                self.sd.logger.error("{} - Asserting string in string failure, string: \"{}\" is not contained in string list: \"{}\""
                                     .format(method_name, string, strings_b))
                self.sd.screenshot(method_name)
                pytest.fail(str(e))

    @allure.step("Verify lists are equal")
    def verify_lists_match(self, list_a: [], list_b: [], method_name: str = None):
        if method_name is None:
            method_name = self.sd.callers_names()
        self.sd.logger.info("{} - Asserting list: \"{}\" and list: \"{}\" are equal".format(method_name, list_a, list_b))
        try:
            assert len(list_a) == len(list_b), "verify_lists_match - Lists are not same length"
            self.sd.logger.info("{} - Assertion lists are equal part successful, the lists are of same length".format(method_name))
            assert COL.Counter(list_a) == COL.Counter(list_b), "verify_lists_match - Lists do not contain same elements"
            self.sd.logger.info("{} - Assertion lists are equal fully successful, the lists containing same elements".format(method_name))
        except AssertionError as e:
            self.sd.logger.error("{} - Assertion lists are equal failure, list: \"{}\" and list: \"{}\" are not equal"
                                 .format(method_name, list_a, list_b))
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    @allure.step("Verify string list is not contained in another string list")
    def verify_string_not_in_strings(self, strings_a: [], strings_b: [], method_name: str = None):
        if method_name is None:
            method_name = self.sd.callers_names()
        self.sd.logger.info("{} - Asserting no strings from : \"{}\" are contained in: \"{}\"".format(method_name, strings_a, strings_a))
        for string in strings_a:
            try:
                assert string not in strings_b, "verify_string_in_string - string \"{}\" is in list: \"{}\"".format(string, strings_b)
                self.sd.logger.info("{} - Assertion string: \"{}\" not in string list \"{}\" success".format(method_name, string, strings_b))
            except AssertionError as e:
                self.sd.logger.error("{} - Asserting string not in string list failure, string: \"{}\" is contained in string list: \"{}\""
                                     .format(method_name, string, strings_b))
                self.sd.screenshot(method_name)
                pytest.fail(str(e))

    @allure.step("Verify element is enabled/disabled")
    def is_enabled(self, element, expected, method_name: str = None):
        if method_name is None:
            method_name = self.sd.callers_names()
        log_msg = "enabled" if expected is True else "disabled"
        self.sd.logger.info("{} - Asserting element is {}".format(method_name, log_msg))
        try:
            assert element.is_enabled() is expected, "is_enabled - at method: {}".format(method_name)
            self.sd.logger.info("{} - Assertion element is {} success".format(method_name, log_msg))
        except AssertionError as e:
            self.sd.logger.error("{} - Assertion element is {} failure".format(method_name, log_msg))
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    @allure.step("Verify element is bigger")
    def is_bigger(self, expected, actual, method_name: str = None):
        """is actual bigger than expected"""
        if method_name is None:
            method_name = self.sd.callers_names()
        self.sd.logger.info("{} - Asserting actual value \"{}\" is bigger than expected \"{}\"".format(method_name, actual, expected))
        try:
            assert actual > expected, "is_bigger - actual not bigger than expected at method: {}".format(method_name)
            self.sd.logger.info("{} - Assertion actual value is bigger than expected success".format(method_name))
        except AssertionError as e:
            self.sd.logger.error("{} - Assertion actual value is bigger than expected failure, \"{}\" is not bigger than \"{}\""
                                 .format(method_name, actual, expected))
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    @allure.step("Verify element is smaller")
    def is_smaller(self, expected, actual, method_name: str = None):
        if method_name is None:
            method_name = self.sd.callers_names()
        self.sd.logger.info("{} - Asserting actual value \"{}\" is smaller than expected \"{}\"".format(method_name, actual, expected))
        try:
            assert actual < expected, "is_smaller - actual not smaller than expected at method: {}".format(method_name)
            self.sd.logger.info("{} - Assertion actual value is smaller than expected success".format(method_name))
        except AssertionError as e:
            self.sd.logger.error("{} - Assertion actual value is smaller than expected failure, \"{}\" is not bigger than \"{}\""
                                 .format(method_name, actual, expected))
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    @allure.step("Verify element is displayed")
    def is_displayed(self, actual, method_name: str = None):
        if method_name is None:
            method_name = self.sd.callers_names()
        self.sd.logger.info("{} - Asserting element is displayed".format(method_name))
        try:
            assert actual.is_displayed(), "Element is not displayed at method: {}".format(method_name)
            self.sd.logger.info("{} - Assertion element is displayed success".format(method_name))
        except AssertionError as e:
            self.sd.logger.error("{} - Assertion element is displayed failure".format(method_name))
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    def is_not_displayed(self, locator=None, locator_type=None, actual=None, method_name=None):
        if method_name is None:
            method_name = self.sd.callers_names()
        self.sd.logger.info("{} - Asserting element is not displayed".format(method_name))
        if actual is None:
            self.sd.wait_for_element_to_be_gone(locator, locator_type)
            actual = self.sd.get_element(locator=locator, locatorType=self.sd.get_by_type(locator_type))
        try:
            assert not actual.is_displayed()
            self.sd.logger.info("{} - Assertion element is not displayed success".format(method_name))
        except AssertionError as e:
            self.sd.logger.error("{} - Assertion element is displayed failure".format(method_name))
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    @allure.step("Verify value matches with tolerance")
    def verify_value_matches_with_tolerance(self, expected, actual, tolerance, method_name: str = None):
        if method_name is None:
            method_name = self.sd.callers_names()
        try:
            assert expected - tolerance <= actual <= expected + tolerance
        except AssertionError as e:
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    @allure.step("Verify difference is correct")
    def verify_correct_difference(self, expected, actual, difference, error_name: str = None):
        if error_name is None:
            error_name = self.sd.callers_names()
        try:
            assert abs(actual - expected) == abs(difference)
        except AssertionError as e:
            self.sd.screenshot(error_name)
            pytest.fail(str(e))

    @allure.step("Verify value is true")
    def verify_true(self, actual, method_name: str = None):
        if method_name is None:
            method_name = self.sd.callers_names()
        self.sd.logger.info("{} - Asserting truth, actual is: \"{}\"".format(method_name, actual))
        try:
            assert actual is True, "Verification mismatch from '{}' at '{}':\nExpected: True\nActual: {}" \
                .format(self.verify_values_match.__name__, method_name, str(actual))
            self.sd.logger.info("{} - Assertion file exists success".format(self.sd.callers_names()))
        except AssertionError as e:
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    def is_false(self, actual):
        method_name = self.sd.callers_names()
        self.sd.logger.info("{} - Asserting truth, actual is: \"{}\"".format(method_name, actual))
        try:
            assert actual is False, "Verification mismatch from '{}' at '{}':\nExpected: True\nActual: {}" \
                .format(self.verify_values_match.__name__, method_name, str(actual))
            self.sd.logger.info("{} - Assertion file exists success".format(self.sd.callers_names()))
        except AssertionError as e:
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    @allure.step("Verify file exist")
    def verify_file_exist(self, file_path: str, method_name: str = None):
        if method_name is None:
            method_name = self.sd.callers_names()
        self.sd.logger.info("{} - Asserting file exists: \"{}\"".format(method_name, file_path))
        try:
            assert os.path.exists(file_path) is True, "File at path '{}' does not exist".format(file_path)
            self.sd.logger.info("{} - Assertion file exists success".format(method_name))
        except AssertionError as e:
            self.sd.logger.error("{} - Assertion file exists failure".format(method_name))
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    @allure.step("Verify argument is None")
    def verify_is_none(self, actual: any, method_name: str = None):
        """
        verify by assertion that the argument is not 'None'.\n
        :param actual: the argument to verify (any type).
        :param method_name: the caller method.
        """
        if method_name is None:
            method_name = self.sd.callers_names()
        self.sd.logger.info("{} - Asserting argument is None:\n\tActual: \"{}\"\n\tAt: \"{}\"".format(method_name, actual, method_name))
        try:
            assert actual is None, "Argument is not None"
            self.sd.logger.info("{} - Assertion value is none success".format(method_name))
        except AssertionError as e:
            self.sd.logger.error("{} - Assertion failed, value is not none:\n\tActual: \"{}\"\n\tAt: \"{}\""
                                 .format(method_name, actual, method_name))
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    @allure.step("Verify argument is not None")
    def verify_not_none(self, actual: any, method_name: str = None):
        if method_name is None:
            method_name = self.sd.callers_names()
        """
        verify by assertion that the argument is not 'None'.\n
        :param actual: the argument to verify (any type).
        :param method_name: the caller method.
        """
        self.sd.logger.info("{} - Asserting argument is not None:\n\tActual: \"{}\"\n\tAt: \"{}\""
                            .format(method_name, actual, method_name))
        try:
            assert actual is not None, "Argument is None"
            self.sd.logger.info("{} - Assertion value is not none success".format(method_name))
        except AssertionError as e:
            self.sd.logger.error("{} - Assertion failed, value is none:\n\tActual: \"{}\"\n\tAt: \"{}\""
                                 .format(method_name, actual, method_name))
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    def is_exist(self, element):
        self.sd.logger.info("{} -   asserting element exists: element: {}".format(self.sd.callers_names(), str(element)))
        self.verify_not_none(actual=element, method_name=self.sd.callers_names())

    def is_not_exist(self, element):
        if element is None:
            self.verify_is_none(actual=element)
        else:
            method_name = self.sd.callers_names()
            try:
                self.sd.logger.info("{} -   asserting element exists: element: {}".format(method_name, str(element)))
                assert self.sd.wait_for_stateless_element(element=element) is True
                self.sd.logger.info("{} -   asserting element exists: element: {} does not exist".format(method_name, str(element)))
            except AssertionError as e:
                self.sd.logger.error("{} - Assertion failed, element not stateless:\n\tActual: \"{}\"\n\tAt: \"{}\""
                                     .format(method_name, str(element), method_name))
                self.sd.screenshot(method_name)
                pytest.fail(str(e))
        # self.sd.wait(2)
        # self.sd.logger.info("{} -   asserting element exists: element: {}".format(method_name, str(element)))
        # self.verify_is_none(actual=element, method_name=method_name)

    def match_strings_up_to_index(self, s1: str, s2: str, index: int, method_name=None):
        try:
            if s1 is None or s2 is None:
                raise Exception("One or both strings are none")
            if method_name is None:
                method_name = self.sd.callers_names()
            if len(s1) >= len(s2):
                bigger_string = len(s1)
            else:
                bigger_string = len(s2)
            for i in range(bigger_string):
                if i < index:
                    assert s1[i] == s2[i]
                else:
                    break
        except AssertionError as e:
            self.sd.logger.error(f"assertion failed, strings {s1} and {s2} don't match up to index {index}")
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    def match_strings_up_to_character(self, s1: str, s2: str, character: str, char_amount=1, method_name=None):
        """
        verifies that s2 is equal to s1 up to the n-th appearance of character
        :param s1: the first string. this is the string the character and char_index parameters should reference
        :param s2: the second string
        :param character: the character up to do the check
        :param char_amount: the character n-th appearance
        :param method_name: methods name - you don't have to pass this argument
        :return: None
        """
        try:
            if s1 is None or s2 is None:
                raise Exception("One or both strings are none")
            if method_name is None:
                method_name = self.sd.callers_names()
            if len(s1) >= len(s2):
                bigger_string = len(s1)
            else:
                bigger_string = len(s2)
            char_count = 0
            for i in range(bigger_string):
                if s1[i] == character:
                    char_count = char_count + 1
                    if char_count >= char_amount:
                        break
                assert s1[i] == s2[i]
        except AssertionError as e:
            self.sd.logger.error(f"assertion failed, strings {s1} and {s2} don't match up to character: {character} at n-th appearance: {char_amount}")
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    def verify_value_not_matches_with_tolerance(self, expected, actual, tolerance, method_name=None):
        try:
            assert expected - tolerance >= actual >= expected + tolerance
        except AssertionError as e:
            self.sd.screenshot(method_name)
            pytest.fail(str(e))

    def verify_matches_softly(self, expected, actual, method_name=None):
        if method_name is None:
            method_name = self.sd.callers_names()
        check.equal(a=expected, b=actual)
        self.sd.screenshot(method_name)

    def verify_not_matches_softly(self, expected, actual, method_name=None):
        if method_name is None:
            method_name = self.sd.callers_names()
        check.not_equal(a=expected, b=actual)
        self.sd.screenshot(method_name)
