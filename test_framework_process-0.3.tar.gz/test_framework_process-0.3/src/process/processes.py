import subprocess
import time

import allure
import requests
import json

from utilities.xml_reader import *
from root_dir import get_root_dir


@allure.step("Start RC")
def start_rc() -> None:
    """
    Remotely starts the RC server, takes it's needed parameters (like the IP address) from the XML file.\n
    """
    cmd = r"{root_dir}\plink.exe -ssh -pw {password} {username}@{ip} -batch Start_RC Automation_mmr set_sw_lab".format(
        root_dir=get_root_dir(),
        password=get_node("linux_pass"),
        username=get_node("linux_user"),
        ip=get_node("linux_ip")
    )
    timeout_s = 5

    try:
        p = subprocess.Popen(cmd)
        p.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        subprocess.call(['taskkill', '/F', '/T', '/PID', str(p.pid)])


def stop_rc():
    """
    Remotely stops the RC server
    """
    cmd = r"{root_dir}\plink.exe -ssh -pw {password} {username}@{ip} -batch Stop_RC".format(
        root_dir=get_root_dir(),
        password=get_node("linux_pass"),
        username=get_node("linux_user"),
        ip=get_node("linux_ip")
    )
    timeout_s = 5

    try:
        p = subprocess.Popen(cmd)
        p.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        subprocess.call(['taskkill', '/F', '/T', '/PID', str(p.pid)])


@allure.step("Edit AES reference point file")
def edit_aes_ref(east, north, height) -> None:
    """
    Remotely edits the AES Reference Point file to be used when starting RES scenarios.\n
    :param east: The Longitude(East) coordinate
    :param north: The Latitude(North) coordinate
    :param height: The Altitude(Heigth) coordinate
    """
    cmd = r"{root_dir}\plink.exe -ssh -pw {password} {username}@{ip} -batch Edit_Ref_Point {lon} {lat} {alt}".format(
        root_dir=get_root_dir(),
        password=get_node("linux_pass"),
        username=get_node("linux_user"),
        ip=get_node("linux_ip"),
        lon=east, lat=north, alt=height)

    timeout_s = 5

    try:
        p = subprocess.Popen(cmd)
        p.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        subprocess.call(['taskkill', '/F', '/T', '/PID', str(p.pid)])


@allure.step("Start RES")
def start_res() -> None:
    """
    Remotely starts the RES simulator, takes it's needed parameters (like the IP address) from the XML file.\n
    """
    cmd = r"{root_dir}\plink.exe -ssh -pw {password} {username}@{ip} -batch Start_RES Automation_mmr set_sw_lab".format(
        root_dir=get_root_dir(),
        password=get_node("linux_pass"),
        username=get_node("linux_user"),
        ip=get_node("linux_ip"))

    timeout_s = 5
    try:
        p = subprocess.Popen(cmd)
        p.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        subprocess.call(['taskkill', '/F', '/T', '/PID', str(p.pid)])


@allure.step("Stops res")
def stop_res():
    """
     Remotely stops the RES server
     """
    cmd = r"{root_dir}\plink.exe -ssh -pw {password} {username}@{ip} -batch Stop_RES".format(
        root_dir=get_root_dir(),
        password=get_node("linux_pass"),
        username=get_node("linux_user"),
        ip=get_node("linux_ip"))

    timeout_s = 5
    try:
        p = subprocess.Popen(cmd)
        p.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        subprocess.call(['taskkill', '/F', '/T', '/PID', str(p.pid)])


@allure.step("Run RES Scenario")
def run_scenario(name) -> None:
    """
    Remotely starts a RES scenario with the given name, takes it's needed parameters (like the IP address) from the XML file.\n
    :param name: the name of the RES scenario to run, including the affix.
    """
    cmd = r"{root_dir}\plink.exe -ssh -pw {password} {username}@{ip} -batch cd {aes_dir} && AES {scenarios_dir}{scenario}".format(
        root_dir=get_root_dir(),
        password=get_node("linux_pass"),
        username=get_node("linux_user"),
        ip=get_node("linux_ip"),
        aes_dir=get_node("aes_dir"),
        scenarios_dir=get_node("scenarios_dir"),
        scenario=name)
    timeout_s = 5

    try:
        p = subprocess.Popen(cmd)
        p.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        subprocess.call(['taskkill', '/F', '/T', '/PID', str(p.pid)])


@allure.step("Restart CPS")
def restart_cps():
    """
    Remotely restarts the CPS server using an already online node server on the same machine,
    takes it's needed parameters (like the IP address) from the XML file.\n
    """
    restart_path = "http://{}:{}{}".format(get_node("cps_ip"), get_node("cps_server_port"),
                                           get_node("cps_restart_path"))
    response = requests.get(restart_path)
    res_txt = json.loads(response.text)
    return res_txt


@allure.step("Stops CPS")
def stop_cps():
    """
    Remotely restarts the CPS server using an already online node server on the same machine,
    takes it's needed parameters (like the IP address) from the XML file.\n
    """
    restart_path = "http://{}:{}{}".format(get_node("cps_ip"), get_node("cps_server_port"),
                                           get_node("cps_stop_path"))
    response = requests.get(restart_path)
    res_txt = json.loads(response.text)
    return res_txt


@allure.step("Start GeoServer")
def start_geo_server():
    restart_path = "http://{}:{}{}".format(get_node("cps_ip"), get_node("cps_server_port"), get_node("geo_start_path"))
    response = requests.get(restart_path)
    res_txt = json.loads(response.text)
    # print(json.dumps(res_txt, indent=2, sort_keys=True))
    print("\n{}".format(res_txt))


@allure.step("Kill CPS")
def kill_cps() -> None:
    cmd = 'taskkill /IM "S4C.exe" /F'
    subprocess.call(cmd)


@allure.step("Get remote folder content")
def get_session_dir_content(dir_path: str, computer_name: str, folder_name: str):
    """
    Returns the full content of the remote directory.
    :param folder_name:
    :param computer_name:
    :param dir_path: The path to the required directory.
    :return:
    """
    cmd = r'{}\psexec.exe \\{} powershell "dir -n {}\{}"'.format(get_root_dir(), get_node(computer_name),
                                                                 dir_path, get_node(folder_name))
    cmd1 = r'{}\psexec.exe \\{} powershell "dir -n {}\{}"'.format(get_root_dir(), get_node(computer_name),
                                                                  dir_path, get_node(folder_name))
    p = subprocess.Popen(cmd1, shell=True, stdout=subprocess.PIPE, universal_newlines=True)
    res = ""
    time.sleep(2)
    for line in p.stdout:
        res = res + line
    allure.attach(res[res.index(".com") + 4:], name="Directory Content")
    return res[res.index(".com") + 4:]
