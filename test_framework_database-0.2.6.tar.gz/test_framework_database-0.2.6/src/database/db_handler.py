from database.database2 import Database
from database.db_exception import *


class DBHandler:
    """
    works with db2.
    inherit this class and override on_database_information()
    """
    db = None
    dbe = None

    SERVER_NAME = "servername"
    DB_USER_NAME = "dbUserName"
    DB_PASSWORD = "dbPassword"
    DBNAME = "dbname"

    def __init__(self) -> None:
        self.db = Database()
        self.dbe = DBException()
        self._connect()

    def _connect(self):
        db_information = self._on_database_information()
        if not bool(db_information):
            raise self.dbe.data_doesnt_exist_exception("db information wasn't provided, did you forget to override the on_database_information() function")
        self.db.server = db_information.get(self.SERVER_NAME)
        self.db.password = db_information.get(self.DB_PASSWORD)
        self.db.username = db_information.get(self.DB_USER_NAME)
        self.db.db_name = db_information.get(self.DBNAME)
        self.db.conn = self.db.connect()
        self.db.cursor = self.db.conn.cursor(as_dict=True)

    def _on_database_information(self) -> dict:
        """
        override this function when implementing database class
        returns a dict with the relevant sql database information
        use the name constants at the top of this class as keys
        :return:
        """
        pass

    def send_query(self, query):
        self.db.query(query)
        return self.db.get_cursor().fetchall()

    def send_query_no_response(self, query):
        self.db.query(query)

    def send_query_for_single_value(self, query, name: str):
        self.db.query(query)
        return self.db.get_cursor().fetchone()[name]

    def select(self, table_name, columns: [], condition):
        self.check_correct_data(table_name)
        if columns[0] == "*":
            cols = "*"
        else:
            cols = self.array_as_string(columns)
        if condition is None:
            where = ""
        else:
            where = f"where {condition}"
        query = f"select {cols} from {table_name} {where}"
        return self.send_query(query)

    def insert(self, table_name, columns: [], values: []):
        try:
            self.check_correct_data(table_name, columns, values)
            query = f"insert into {table_name} ({self.array_as_string(columns)}) values ({self.array_as_string(values)})"
            print("the query: " + str(query))
            return self.send_query(query)
        except Exception as e:
            print(e)
            return "an error has accured"

    def update(self, table_name, columns: [], values: [], condition):
        self.check_correct_data(table_name, columns, values)
        update_info = ""
        for column, value in zip(columns, values):
            update_info = f" {column} = {value},"
        update_info = update_info.removesuffix(",")
        query = f"update {table_name} set {update_info} where {condition}"
        return self.send_query(query)

    def delete(self, table_name, condition):
        self.is_table_exist(table_name)
        query = f"delete from {table_name} where {condition}"
        return self.send_query(query)

    def is_table_exist(self, table_name):
        query = f"if exists (select * from INFORMATION_SCHEMA.TABLES where TABLE_NAME = {table_name} begin print True end)"
        return self.send_query(query)

    def is_any_data_exist(self, table_name):
        self.check_correct_data(table_name)
        query = f"select * from {table_name}"
        answer = self.send_query(query)
        return len(answer) > 0

    def array_as_string(self, arr):
        st = ""
        for value in arr:
            st = st + str(value) + ","
        return st.removesuffix(",")

    def check_correct_data(self, table_name, columns: [] = None, values: [] = None):
        if columns is not None:
            if len(columns) != 0:
                if len(columns) != len(values):
                    raise self.dbe.incorrect_query_exception("amount of columns not equal to amount of values")

        return None
        # table_exists = self.is_table_exist(table_name)
        # if not table_exists:
        #     raise self.dbe.table_doesnt_exist_exception(f"the requested table {table_name} doesn't exist")
