class DBException(Exception):

    def incorrect_query_exception(self, e):
        print(e)
        self.with_traceback(None)

    def data_doesnt_exist_exception(self, e):
        pass

    def table_doesnt_exist_exception(self, e):
        pass

    def permission_denied_exception(self, e):
        pass

    def logic_violation_exception(self, e):
        pass


