import pymssql
import allure


class Database:
    conn: pymssql.Connection = None
    cursor = None

    SERVER_NAME = "servername"
    DB_USER_NAME = "dbUserName"
    DB_PASSWORD = "dbPassword"
    DBNAME = "dbname"

    def __init__(self):
        self.db_name = None
        self.password = None
        self.username = None
        self.server = None

    @allure.step("initialize database data")
    def init_db_connection(self):
        db_data = self.get_db_data()
        if not bool(db_data):
            raise Exception("cant initialize database with missing information")
        self.server = db_data.get(self.SERVER_NAME)
        self.username = db_data.get(self.DB_USER_NAME)
        self.password = db_data.get(self.DB_PASSWORD)
        self.db_name = db_data.get(self.DBNAME)
        self.on_connect()

    @allure.step("connects to database")
    def on_connect(self):
        self.conn = self.connect()
        self.cursor = self.conn.cursor(as_dict=True)

    @allure.step("returns a dict with the correct db data")
    def get_db_data(self):
        pass

    @allure.step("Establish Database Connection")
    def connect(self):
        """
        Returns connection object
        """
        return pymssql.connect(self.server, self.username, self.password, self.db_name)

    @allure.step("Get The Connection Object")
    def get_connection(self):
        """
        Returns connection object
        """
        return self.conn

    @allure.step("Get The Cursor Object")
    def get_cursor(self):
        """
        Returns cursor object in a dictionary form
        """
        return self.cursor

    @allure.step("Close Database Connection")
    def close(self):
        """
        Closes the connection
        """
        self.conn.close()

    @allure.step("Execute Query")
    def query(self, query: str):
        """
        Executes the given query

        :param query: The query to execute
        """
        self.cursor.execute(query)

    @allure.step("Commit Changes To The Database")
    def commit(self):
        """
        Commits the changes to the database
        """
        self.conn.commit()
