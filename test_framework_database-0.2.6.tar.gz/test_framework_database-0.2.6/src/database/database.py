import pymssql
import allure


class Database:
    conn: pymssql.Connection = None
    cursor = None

    def __init__(self, server: str, username: str, password: str, db_name: str):
        self.server = server
        self.username = username
        self.password = password
        self.db_name = db_name
        self.conn = self.connect()
        self.cursor = self.conn.cursor(as_dict=True)

    @allure.step("Establish Database Connection")
    def connect(self):
        """
        Returns connection object
        """
        return pymssql.connect(self.server, self.username, self.password, self.db_name)

    @allure.step("Get The Connection Object")
    def get_connection(self):
        """
        Returns connection object
        """
        return self.conn

    @allure.step("Get The Cursor Object")
    def get_cursor(self):
        """
        Returns cursor object in a dictionary form
        """
        return self.cursor

    @allure.step("Close Database Connection")
    def close(self):
        """
        Closes the connection
        """
        self.conn.close()

    @allure.step("Execute Query")
    def query(self, query: str):
        """
        Executes the given query

        :param query: The query to execute
        """
        self.cursor.execute(query)

    @allure.step("Commit Changes To The Database")
    def commit(self):
        """
        Commits the changes to the database
        """
        self.conn.commit()
