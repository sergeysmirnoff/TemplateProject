import xml.etree.ElementTree as et
import utilities.xml_reader as reader
from database.db_handler import DBHandler
from utilities.csv_handler import CsvHandler


class Calibrator(DBHandler):
    logger = None
    xml_path = None
    freq_amount = None

    FREQ_ID = "FreqID"
    CALIBRATION_TYPE = "CalibrationType"
    CALIBRATION_STATUS = "CalibrationStatus"
    BEAM_SHAPE_TYPE = "BeamShapeType"
    LAST_UPDATE_TIME = "LastUpdateTime"

    calibration_fields = [FREQ_ID, CALIBRATION_TYPE, BEAM_SHAPE_TYPE, CALIBRATION_STATUS, LAST_UPDATE_TIME]

    calibration_table = "MmrCalibrationOverallStatus"

    def __init__(self, xml_path, logger, freq_amount: int):
        self.xml_path = xml_path
        self.logger = logger
        self.freq_amount = freq_amount
        super().__init__()

    def _on_database_information(self) -> dict:
        return {self.SERVER_NAME: reader.get_data_from_remote_xml(self.xml_path, self.SERVER_NAME),
                self.DBNAME: reader.get_data_from_remote_xml(self.xml_path, self.DBNAME),
                self.DB_USER_NAME: reader.get_data_from_remote_xml(self.xml_path, self.DB_USER_NAME),
                self.DB_PASSWORD: reader.get_data_from_remote_xml(self.xml_path, self.DB_PASSWORD)}

    def init_db(self, config_file_path):
        csv_handler = CsvHandler(logger=self.logger)
        rows, cols = csv_handler.csv_parser(config_file_path)
        print(rows, cols)

    def get_xml_from_db(self, query, xml_tag_path):
        # self.query(query)
        # xml_file = self.get_cursor().fetchone()['XMLFile']
        xml_file = self.send_query_for_single_value(query, 'XMLFile')
        root = et.fromstring(xml_file)
        value = root.findall(xml_tag_path)
        print(value)
        return value

    def build_xml_path(self, xml_tags: [], attribute_names: [], attribute_values: []):
        parser_string = ""
        for tag, name, value in zip(xml_tags, attribute_names, attribute_values):
            parser_string = parser_string + f'{tag}[@{name}="{value}"]//'
        if len(xml_tags) > len(attribute_names):
            parser_string = parser_string + xml_tags[-1]
        return ".//" + parser_string.removesuffix("//")

    def insert_calibration(self, freq_ids: [int], calibration_types: [int], beam_shape_types: [int], last_updates_time):
        return_value_arr = []
        # for calibration_status in calibration_statues:
        for freq_id in freq_ids:
            for calibration_type in calibration_types:
                for beam_shape_type in beam_shape_types:
                    r_msg = self.insert(self.calibration_table, self.calibration_fields,
                                        [freq_id, calibration_type, beam_shape_type, 2,
                                         last_updates_time])
                    return_value_arr.append(r_msg)
        return return_value_arr

    def update_calibration(self, update_values: {}, condition=None):
        freq_id = update_values[self.FREQ_ID]
        cal_type = update_values[self.CALIBRATION_TYPE]
        beam_type = update_values[self.BEAM_SHAPE_TYPE]
        cal_status = update_values[self.CALIBRATION_STATUS]
        l_update_time = update_values[self.LAST_UPDATE_TIME]
        values = [freq_id, cal_type, beam_type, cal_status, l_update_time]
        if condition is None:
            condition = f"where {self.calibration_fields[0]} = {freq_id}"
        return self.update(table_name=self.calibration_table, columns=self.calibration_fields, values=values,
                           condition=condition)

    def is_calibrated(self, table_name, column_name, freq_id, expected_calibration_value: []):
        query = f"select {column_name} from {table_name} where freq_id = {freq_id}"
        return_value = self.send_query(query)
        return str(return_value) in expected_calibration_value

    def calibrate(self):
        xml_path0 = self.build_xml_path(["CalibrationType", "CalibrationBeamShapeType"], ["name", "name"],
                                        ["CHN_TX", "4"])  # returns a path for a specific xml tag
        xml_path_tx = self.build_xml_path(["CalibrationType", "CalibrationBeamShapeType"], ["name"],
                                          ["CHN_TX"])  # returns a path for a list of tags
        query = "select XMLFile from MmrCalibrationAndInitiatedBit where id=1"
        data = self.get_xml_from_db(query, xml_path0)
        tx_data = self.get_xml_from_db(query, xml_path_tx)
        tx_amount = len(tx_data)

        xml_path_rx = self.build_xml_path(["CalibrationType", "CalibrationBeamShapeType"], ["name"], ["CHN_RX"])
        rx_data = self.get_xml_from_db(query, xml_path_rx)
        rx_amount = len(rx_data)

        xml_path_guard = self.build_xml_path(["CalibrationType", "CalibrationBeamShapeType"], ["name"], ["GUARD"])
        guard_data = self.get_xml_from_db(query, xml_path_guard)
        guard_amount = len(guard_data)

        freq_ids = []
        for i in range(1, self.freq_amount):
            freq_ids.append(i)

        calibration_type_header_nCalType = "nCalType"
        calibration_type_header_sCalTypeDescript = "sCalTypeDescript"
        types = self.send_query(
            "select * from MmrCalibrationTypes where sCalTypeDescript = 'RX' or sCalTypeDescript = 'TX' or sCalTypeDescript = 'Guard'")
        rx_calib = None
        tx_calib = None
        guard_calib = None
        for calibration_type in types:
            c_type_header = calibration_type[calibration_type_header_sCalTypeDescript].lower()
            c_type_value = calibration_type[calibration_type_header_nCalType]
            if c_type_header == "RX".lower():
                rx_calib = c_type_value
            elif c_type_header == "TX".lower():
                tx_calib = c_type_value
            elif c_type_header == "Guard".lower():
                guard_calib = c_type_value
        calibration_types = []
        for i in range(rx_amount + tx_amount + guard_amount):
            if i < rx_amount:
                calibration_types.append(rx_calib)
            elif rx_amount <= i < rx_amount + tx_amount:
                calibration_types.append(tx_calib)
            elif rx_amount + tx_amount <= i <= rx_amount + tx_amount + guard_amount:
                calibration_types.append(guard_calib)

        beam_shape_types = []
        for i in range(1, rx_amount + tx_amount + guard_amount):
            if i <= rx_amount:
                beam_shape_types.append(i)
            elif rx_amount < i <= rx_amount + tx_amount:
                beam_shape_types.append(i % rx_amount)
            else:
                beam_shape_types.append(i % (rx_amount + tx_amount))

        # calibration_statuses = []
        # for i in range(len(freq_ids)):
        #     calibration_statuses.append(2)

        last_update_time = "638060111883549596"

        print(tx_data, rx_data, guard_data)
        return self.insert_calibration(freq_ids=freq_ids, calibration_types=calibration_types,
                                       last_updates_time=last_update_time,
                                       beam_shape_types=beam_shape_types)
