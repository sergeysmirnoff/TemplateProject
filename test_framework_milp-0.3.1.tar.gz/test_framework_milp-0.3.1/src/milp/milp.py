import subprocess
import socket
import time
import os.path
import struct
import allure

from utilities.xml_reader import *


class Milp:
    msg_reply_header = '<LLLL'
    msg_config_header = '<LLLHHLH'

    def __init__(self, UDP_IP, UDP_PORT_LOCAL):
        self.UDP_IP = UDP_IP
        self.UDP_PORT_LOCAL = UDP_PORT_LOCAL

    def remote_commamd_request_massage(self, msg_data):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(msg_data, (self.UDP_IP, self.UDP_PORT_LOCAL))

    def open_monitor_cmd(self):
        path = get_node("milp_monitor_cmd")
        return path

    def OpenMonitor(self):
        MilpMonitorFolderPath = get_node("milp_monitor_folder")

        MilpMonitorProc = None
        if os.path.exists(MilpMonitorFolderPath):
            print('file %s not found' % MilpMonitorFolderPath)

            # run Milp Monitor to be ready to receive and store messages
            MilpMonitorPath = get_node("milp_monitor_cmd")
            MilpMonitorProc = subprocess.Popen(MilpMonitorPath)
            time.sleep(3)

        return MilpMonitorProc

    @allure.step("MILP - Start recording")
    # send Milp Monitor start command
    def start_recording(self):
        """
        Starts the recording
        """
        data = struct.pack('<LL', 0, 1)
        self.remote_commamd_request_massage(data)

    @allure.step("MILP - Stop recording")
    # send Milp Monitor stop command
    def stop_recording(self):
        """
        Stops the recording
        """
        data = struct.pack('<LL', 0, 0)
        self.remote_commamd_request_massage(data)

    def GetConfig(self):
        data = struct.pack('<LL', 0, 2)
        self.remote_commamd_request_massage(data)

    def SetConfig(self, config_name):
        len_config_name = len(config_name)
        len_msg = len_config_name + 14

        data = struct.pack('<LLlh' + str(len_config_name) + 's', 0, 3, len_msg, len_config_name, bytes(config_name, 'ascii'))
        self.remote_commamd_request_massage(data)

    def GetStatus(self):
        data = struct.pack('<LL', 0, 4)
        self.remote_commamd_request_massage(data)

    @allure.step("MILP - Record")
    def record(self):
        """
        Records
        """
        data = struct.pack('<LL', 0, 9)
        self.remote_commamd_request_massage(data)

    def Online(self):
        data = struct.pack('<LL', 0, 10)
        self.remote_commamd_request_massage(data)

    @allure.step("MILP - Start session")
    def start_session(self, session_name):
        """
        Starts the session, if no folder named <session_name> exists, creates it.\n
        :param session_name: The folder name in which to create the session file and other needed files
        """
        len_session_name = len(session_name)
        len_msg = len_session_name + 14

        data = struct.pack('<LLlh' + str(len_session_name) + 's', 0, 11, len_msg, len_session_name, bytes(session_name, 'ascii'))
        self.remote_commamd_request_massage(data)

    @allure.step("MILP - Stop session")
    def stop_session(self):
        """
        Stops the session
        """
        data = struct.pack('<LL', 0, 12)
        self.remote_commamd_request_massage(data)

    def RecordingFolder(self, folder_name):
        len_folder_name = len(folder_name)
        len_msg = len_folder_name + 14
        data = struct.pack('<LLlh' + str(len_folder_name) + 's', 0, 13, len_msg, len_folder_name, bytes(folder_name, 'ascii'))
        self.remote_commamd_request_massage(data)

    # Send MILP Monitor ClearLog command
    def ClearLog(self):
        data = struct.pack('<LL', 0, 16)
        self.remote_commamd_request_massage(data)

    # Send MILP Monitor GetInfo command
    def GetInfo(self):
        data = struct.pack('<LL', 0, 17)
        self.remote_commamd_request_massage(data)

    def GetMonitorResponse(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('', self.UDP_PORT_LOCAL))
        sock.settimeout(2.0)
        recvd = []
        try:
            while True:
                recvd.append(sock.recv(1024))
        except:
            pass

        return recvd

    def GetReplyInfo(self, data, f_reply_header=msg_reply_header):
        msgType, commandType, msgLen, InfoLength = struct.unpack(f_reply_header, data[:16])
        msgInfo = data[(msgLen - InfoLength):msgLen].decode('ascii')
        str_command_type = self.GetRemoteCommandMsgString(commandType)
        print('Received ReplyInfo: ', 'commandType=', str_command_type, ', msgInfo: ', msgInfo)

        return str_command_type, msgInfo

    def GetConfigReply(self, data, f_config_header=msg_config_header):
        msgType, commandType, msgLen, configs_no, configs_of, channelstatus, nameLength = struct.unpack(f_config_header, data[:22])
        msgInfo = data[(msgLen - nameLength):msgLen].decode('ascii')
        str_command_type = self.GetRemoteCommandMsgString(commandType)
        str_channel_status = self.GetChannelStatusString(channelstatus)
        print('Received ConfigReply:', 'commandType=', str_command_type, ', Channel Status: ', str_channel_status,
              ', Config no: ', configs_no, '/', configs_of, ', Config Name: ', msgInfo)

        return str_command_type, str_channel_status, configs_no, configs_of, msgInfo

    def GetChannelStatusString(self, value):
        match value:
            case 0: return 'Recording'
            case 1: return 'NotRecording'
            case 2: return 'NotRelevant'
            case _: return 'None'

    def GetRemoteCommandMsgString(self, value):
        match value:
            case 0: return 'Stop'
            case 1: return 'Start'
            case 2: return 'GetConfig'
            case 3: return 'SetConfig'
            case 4: return 'GetStatus'
            case 5: return 'Ack'
            case 6: return 'ConfigNames'
            case 7: return 'Info'
            case 8: return 'Status'
            case 9: return 'Rec'
            case 10: return 'Online'
            case 11: return 'start_session'
            case 12: return 'stop_session'
            case 13: return 'RecordingFolder'
            case 16: return 'ClearLog'
            case 17: return 'GetInfo'
            case _: return 'None'
