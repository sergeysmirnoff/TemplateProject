import inspect
import os
import time
import allure
import pandas as pd
import numpy as np

import milp.milp_processes as mproc
from utilities.xml_reader import get_node
from milp.milp import Milp
from utilities.csv_handler import CsvHandler
from utilities.custom_logger import CustomLogger


class MilpAssistant:

    def __init__(self, logger: CustomLogger) -> None:
        self.logger = logger
        self.milp = Milp(get_node("milp_ip"), int(get_node("milp_port_local")))
        self.session_name = get_node("session_name")
        self.milp_dir = r"\\{}\\{}".format(get_node("milp_ip"), get_node("milp_files"))
        self.messages_paths = {}
        self.csv_handler = CsvHandler(self.logger)

    def setup_milp(self):
        self.logger.info("{} - Started MILP setup".format(self.callers_names()))
        mproc.start_milp_agent()
        time.sleep(2)
        mproc.restart_milp_service()
        time.sleep(2)
        mproc.delete_session_folder(self.session_name)
        time.sleep(3)
        self.milp.start_session(self.session_name)
        time.sleep(3)
        self.logger.info("{} - Finished MILP setup".format(self.callers_names()))

    @allure.step("Add MILP messages paths by message number")
    def add_messages_rc_channel(self, msg_num: str, *msg_nums: str):
        """
        Adds new RC channel message to the messages list.\n
        if msg_num already exist, it will be overridden.\n
        :param msg_num: the message number.
        :param msg_nums: additional messages numbers (optional, variadic).
        """
        self.logger.info("{} - Started adding messages paths".format(self.callers_names()))

        self.messages_paths[msg_num] = "{}{}\\RC_{}.csv".format(self.milp_dir, self.session_name, msg_num)
        self.logger.info("{} - Added message path {} to the paths list".format(self.callers_names(), msg_num))
        for msg in msg_nums:
            self.messages_paths[msg] = "{}{}\\RC_{}.csv".format(self.milp_dir, self.session_name, msg)
            self.logger.info("{} - Added message path {} to the paths list".format(self.callers_names(), msg))

        self.logger.info("{} - Finished adding messages paths".format(self.callers_names()))

    def add_messages_irc_channel(self, msg_num: str, *msg_nums: str):
        """
        Adds new iRC channel message to the messages list.\n
        if msg_num already exist, it will be overridden.\n
        :param msg_num: the message number.
        :param msg_nums: additional messages numbers (optional, variadic).
        """
        self.logger.info("{} - Started adding messages paths".format(self.callers_names()))

        self.messages_paths[msg_num] = "{}{}\\IRC_{}.csv".format(self.milp_dir, self.session_name, msg_num)
        self.logger.info("{} - Added message path {} to the paths list".format(self.callers_names(), msg_num))
        for msg in msg_nums:
            self.messages_paths[msg] = "{}{}\\IRC_{}.csv".format(self.milp_dir, self.session_name, msg)
            self.logger.info("{} - Added message path {} to the paths list".format(self.callers_names(), msg))

        self.logger.info("{} - Finished adding messages paths".format(self.callers_names()))

    @allure.step("Add MILP message paths by message number and full path")
    def add_message_full_path(self, msg_num, msg_path):
        """
        Adds new message to the messages list.\n
        The path is provided by the user, if msg_num already exist, it will be overridden.\n
        :param msg_num: the message number.
        :param msg_path: the message path.
        """
        self.logger.info("{} - Started Adding message \"{}\" path \"{}\" to the messages path list".format(self.callers_names(), msg_num, msg_path))
        self.messages_paths[msg_num] = msg_path
        self.logger.info("{} - Finished Adding message \"{}\" path \"{}\" to the messages path list".format(self.callers_names(), msg_num, msg_path))

    @allure.step("Set milp directory")
    def set_milp_dir(self, milp_dir: str):
        """
        Set the MILP directory to the given one.\n
        :param milp_dir: the new MILP directory.
        """
        self.logger.info("{} - Started Setting MILP directory to be \"{}\"".format(self.callers_names(), milp_dir))
        self.milp_dir = milp_dir
        self.logger.info("{} - Finished Setting MILP directory to be \"{}\"".format(self.callers_names(), milp_dir))

    @allure.step("MILP - full recording process")
    def start_recording(self):
        """
        Initiate the recording process, including the wait.\n
        """
        self.milp.start_recording()
        self.milp.record()
        time.sleep(3)
        self.logger.info("{} - Started MILP recording".format(self.callers_names()))

    @allure.step("MILP - full stop recording process")
    def stop_recording(self):
        """
        Stops the recording process, including the wait.\n
        """
        time.sleep(2)
        self.milp.stop_recording()
        time.sleep(5)
        self.logger.info("{} - Stopped MILP recording".format(self.callers_names()))

    @allure.step("MILP - extract data")
    def milp_msg_rc_channel_extractor(self, config_name: str):
        """
        Checks if messages file exist and if so extracts the messages to CSV files.\n
        Extracts only from the RC channel.\n
        :param config_name: the name of the config extraction.
        """
        self.logger.info("{} - Started MILP Extraction".format(self.callers_names()))
        itdRC = "{}{}\\rc_RC_1.itd".format(self.milp_dir, self.session_name)
        self.logger.info("{} - ITD file full path should be: \"{}\"".format(self.callers_names(), itdRC))

        if not os.path.exists(itdRC):
            self.logger.error("{} - MILP Extraction failed - RC channel recording file is non existent".format(self.callers_names()))
            raise FileNotFoundError("The RC channel ITD file does not exist, check your MILP agent")

        itd_files_dir = "{}{}".format(self.milp_dir, self.session_name)
        self.logger.info("{} - Checking if all ITD files in directory \"{}\" have a size bigger than 0".format(self.callers_names(), itd_files_dir))
        for file in os.listdir(itd_files_dir):
            file_path = "{}\\{}".format(itd_files_dir, file)
            self.logger.info("{} - Checking the size of file \"{}\" with full path \"{}\"".format(self.callers_names(), file, file_path))
            if file.endswith(".itd") and os.path.getsize(file_path) == 0:
                self.logger.info("{} - File \"{}\" is empty and will be removed".format(self.callers_names(), file))
                try:
                    os.remove(file_path)
                    self.logger.info("{} - File \"{}\" was removed".format(self.callers_names(), file))
                except Exception as e:
                    self.logger.error("{} - Exception \"{}\" occurred while trying to remove the file \"{}\""
                                      .format(self.callers_names(), type(e).__name__, file))

                time.sleep(1)

        itc_size = os.path.getsize(itdRC)
        wait_time = 0
        while itc_size == 0:
            time.sleep(1)
            wait_time = wait_time + 1
            itc_size = os.path.getsize(itdRC)
            if wait_time > 120:
                self.logger.error("{} - MILP Extraction failed - RC channel recording is still empty after 2 minutes".format(self.callers_names()))
                raise FileExistsError(
                    "The RC Channel recording file is still empty, make sure you properly stopped the recording")

        mproc.milp_extract(config_name)

        wait_time = 0
        while not all([os.path.exists(msg) for msg in self.messages_paths.values()]):
            time.sleep(1)
            wait_time = wait_time + 1
            if wait_time > 120:
                self.logger.error("{} - MILP Extraction failed - one or more of the extraction files were not created or taking too long to be "
                                  "created".format(self.callers_names()))
                raise FileNotFoundError(
                    "One or more of the extraction files were not created or taking too long to be created")

        self.logger.info("{} - Finished MILP Extraction".format(self.callers_names()))

    @allure.step("MILP - extract data")
    def milp_msg_irc_channel_extractor(self, config_name: str):
        """
        Checks if messages file exist and if so extracts the messages to CSV files.\n
        Extracts only from the RC channel.\n
        :param config_name: the name of the config extraction.
        """
        max_wait_time = 360
        self.logger.info("{} - Started MILP Extraction".format(self.callers_names()))
        itdRC = "{}{}\\irc_IRC_1.itd".format(self.milp_dir, self.session_name)
        self.logger.info("{} - ITD file full path should be: \"{}\"".format(self.callers_names(), itdRC))

        if not os.path.exists(itdRC):
            self.logger.error(
                "{} - MILP Extraction failed - iRC channel recording file is non existent".format(self.callers_names()))
            raise FileNotFoundError("The iRC channel ITD file does not exist, check your MILP agent")

        itd_files_dir = "{}{}".format(self.milp_dir, self.session_name)
        self.logger.info(
            "{} - Checking if all ITD files in directory \"{}\" have a size bigger than 0".format(self.callers_names(),
                                                                                                  itd_files_dir))
        for file in os.listdir(itd_files_dir):
            file_path = "{}\\{}".format(itd_files_dir, file)
            self.logger.info(
                "{} - Checking the size of file \"{}\" with full path \"{}\"".format(self.callers_names(), file,
                                                                                     file_path))
            if file.endswith(".itd") and os.path.getsize(file_path) == 0:
                self.logger.info("{} - File \"{}\" is empty and will be removed".format(self.callers_names(), file))
                try:
                    os.remove(file_path)
                    self.logger.info("{} - File \"{}\" was removed".format(self.callers_names(), file))
                except Exception as e:
                    self.logger.error("{} - Exception \"{}\" occurred while trying to remove the file \"{}\""
                                      .format(self.callers_names(), type(e).__name__, file))

                time.sleep(1)

        itc_size = os.path.getsize(itdRC)
        wait_time = 0
        while itc_size == 0:
            time.sleep(1)
            wait_time = wait_time + 1
            itc_size = os.path.getsize(itdRC)
            if wait_time > max_wait_time:
                self.logger.error(
                    "{} - MILP Extraction failed - iRC channel recording is still empty after {max_wait_time} seconds".format(
                        self.callers_names(), max_wait_time=max_wait_time))
                raise FileExistsError(
                    "The iRC Channel recording file is still empty, make sure you properly stopped the recording")

        mproc.milp_extract(config_name)

        wait_time = 0
        while not all([os.path.exists(msg) for msg in self.messages_paths.values()]):
            time.sleep(1)
            wait_time = wait_time + 1
            if wait_time > max_wait_time:
                self.logger.error(
                    "{} - MILP Extraction failed - one or more of the extraction files were not created or taking too long to be "
                    "created".format(self.callers_names()))
                raise FileNotFoundError(
                    "One or more of the extraction files were not created or taking too long to be created")

        self.logger.info("{} - Finished MILP Extraction".format(self.callers_names()))

    @allure.step("Prepare CSV for querying")
    def prepare_csv(self, msg_path: str, start_index: int, end_index: int, header_to_ignore: str, *headers_to_ignore: str) -> None:
        """
        Rename columns names containing '[' or ']' to not confuse Pandas in particular and Python in general, and drops unneeded columns.\n
        :param msg_path: the path to the message to manipulate.
        :param start_index: the start index for the columns to drop (including).
        :param end_index: the end index for the columns to drop (excluding).
        :param header_to_ignore: the name of the column to drop, the indices are added to this name and then drop.
        :param headers_to_ignore: additional columns names to drop, same as with the singular (optional, variadic).
        """
        self.logger.info("{} - Started preparing CSV file \"{}\"".format(self.callers_names(), msg_path))
        time.sleep(3)
        df = pd.read_csv(msg_path)
        self.logger.info("{} - Read CSV file \"{}\" into a Pandas DataFrame".format(self.callers_names(), msg_path))

        df.columns = df.columns.str.replace(r'\[', '_', regex=True)
        self.logger.info("{} - Replaced columns names with \"[\" char to be \"_\" char".format(self.callers_names()))

        df.columns = df.columns.str.replace(r'\]', '', regex=True)
        self.logger.info("{} - Replaced columns names with \"]\" to be empty char".format(self.callers_names()))

        ignore_text = header_to_ignore
        if len(headers_to_ignore) > 0:
            ignore_text = ignore_text + ", " + ", ".join(headers_to_ignore)

        self.logger.info("{} - Started Dropping unneeded columns: \"[{}]\"".format(self.callers_names(), ignore_text))
        time.sleep(2)
        df = self.csv_handler.drop_unneeded_columns(df, self.csv_handler.headers_to_ignore(start_index, end_index, header_to_ignore, *headers_to_ignore))
        time.sleep(2)
        self.logger.info("{} - Finished Dropping unneeded columns: \"[{}]\"".format(self.callers_names(), ignore_text))

        df.to_csv(path_or_buf=os.path.abspath(msg_path), index=False)
        self.logger.info("{} - Exported DataFrame file back to the given path \"{}\"".format(self.callers_names(), msg_path))
        self.logger.info("{} - Finished preparing CSV file".format(self.callers_names()))

    @allure.step("Truncate CSV columns")
    def truncate_columns(self, msg_path: str, nums_of_digits: int, col_name: str, *cols_names: str):
        cols_names_text = col_name
        if len(cols_names) > 0:
            cols_names_text = col_name + ", " + ", ".join(cols_names)

        self.logger.info("{} - Started truncating values in columns \"[{}]\" to be of {} digits long in CSV file \"{}\""
                         .format(self.callers_names(), cols_names_text, nums_of_digits, msg_path))
        time.sleep(3)
        df = pd.read_csv(msg_path)
        self.logger.info("{} - Read CSV file \"{}\" into a Pandas DataFrame".format(self.callers_names(), msg_path))

        df[col_name] = np.trunc((10 ** nums_of_digits) * df[col_name]) / (10 ** nums_of_digits)
        self.logger.info("{} - Truncated column \"{}\"".format(self.callers_names(), col_name))
        for col in cols_names:
            df[col] = np.trunc((10 ** nums_of_digits) * df[col]) / (10 ** nums_of_digits)
            self.logger.info("{} - Truncated column \"{}\"".format(self.callers_names(), col))

        time.sleep(2)
        df.to_csv(path_or_buf=os.path.abspath(msg_path), index=False)
        self.logger.info("{} - Exported DataFrame file back to the given path \"{}\"".format(self.callers_names(), msg_path))
        self.logger.info("{} - Finished truncating columns in CSV file".format(self.callers_names()))

    def stop_session(self):
        self.milp.stop_session()

    def callers_names(self) -> str:
        """
        Returns the caller class and method names.\n
        """
        inspector = inspect.stack()[1][0]
        caller_class = inspector.f_locals["self"].__class__.__name__
        caller_method = inspector.f_code.co_name
        caller_line = inspect.currentframe().f_back.f_lineno
        return "{}::{}::{}".format(caller_class, caller_method, caller_line)
