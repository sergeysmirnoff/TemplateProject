import subprocess
import allure

from utilities.xml_reader import *
from root_dir import get_root_dir


@allure.step("Start MILP agent")
def start_milp_agent():
    """
    Remotely starts the MILP agent in the LINUX(RC/RES) machine.\n
    Gets the machine ip and user from the XML config file.\n
    Kills the local process after 5 seconds to be able to continue, remote process stays on until kill command is sent.\n
    """
    cmd = r"{root_dir}\plink.exe -ssh -pw {password} {username}@{ip} -batch Start_Milp".format(
        root_dir=get_root_dir(),
        password=get_node("linux_pass"),
        username=get_node("linux_user"),
        ip=get_node("linux_ip")
    )

    timeout_s = 5

    try:
        p = subprocess.Popen(cmd)
        p.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        subprocess.call(['taskkill', '/F', '/T', '/PID', str(p.pid)])


@allure.step("Delete session folder")
def delete_session_folder(sessionName):
    """
    Deletes the directory associated with the given session name.\n
    :param sessionName: The session to delete.
    """
    cmd = r'{}\psexec.exe \\{} cmd /c "rmdir /s /q {}{}"'.format(get_root_dir(), get_node("milp_computer_name"),
                                                                 get_node("ext_itd_folder"), sessionName)

    subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)


def change_environment(env_name):
    extExeLocation = get_node("ext_exe_loc")
    pc_name = get_node("milp_computer_name")
    root_dir = get_root_dir()
    cmd = fr'{root_dir}\psexec.exe \\{pc_name} "{extExeLocation}" -switch mmr_430'
    subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


@allure.step("Invoke MILP extraction")
def milp_extract(config_name: str):
    """
    Invokes the MILP extractor with from the batch file.\n
    Gets the batch file parameters from the XML config file.
    """
    extBatLocation = get_node("ext_bat_loc")
    extExeLocation = get_node("ext_exe_loc")
    extConfig = get_node(config_name)
    outFolder = '{}{}'.format(get_node("ext_out_folder"), get_node("session_name"))
    itdFolder = '{}{}'.format(get_node("ext_itd_folder"), get_node("session_name"))
    cmd = r'{root_dir}\psexec.exe \\{pc_name} {bat_location} "{ext_location}" "{config}" "{out}" "{itd_dir}"'.format(
        root_dir=get_root_dir(),
        pc_name=get_node("milp_computer_name"),
        bat_location=extBatLocation,
        ext_location=extExeLocation,
        config=extConfig,
        out=outFolder,
        itd_dir=itdFolder)

    subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


@allure.step("Restart MILP Monitor service")
def restart_milp_service():
    """
    Restarts the MILP Monitor service on it's machine, this need to be done after starting the agent.\n
    """
    cmd = "Restart-Service -Force -Name 'MilpNG Monitor Service'"
    ic = "Invoke-Command -ComputerName {} -ScriptBlock {}".format(get_node("milp_computer_name"), {cmd})

    subprocess.run(["powershell", "-Command", ic], capture_output=True)


@allure.step("Kills MILP Monitor Service")
def end_milp_service(psexec_path, computer_ip):
    stop_service_command = fr'{psexec_path}  \\{computer_ip} cmd /c NET STOP "MilpNG Monitor Service"'
    return subprocess.Popen(stop_service_command, shell=True, stdout=subprocess.PIPE)


@allure.step("Starts MILP Monitor Service")
def start_milp_service(psexec_path, computer_ip):
    start_service_command = fr'{psexec_path}  \\{computer_ip} cmd /c NET START "MilpNG Monitor Service"'
    return subprocess.Popen(start_service_command, shell=True, stdout=subprocess.PIPE)
