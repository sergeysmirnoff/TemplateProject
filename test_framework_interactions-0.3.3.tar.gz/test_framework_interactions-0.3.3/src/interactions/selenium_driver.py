import datetime
import inspect
import re
import time
import os

import allure
import mouse
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from traceback import print_stack

from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import *
from utilities.custom_logger import CustomLogger
import selenium.webdriver as we
from root_dir import get_root_dir


# noinspection PyMethodMayBeStatic,PyBroadException
class SeleniumDriver:
    logger = None

    def __init__(self, driver, logger: CustomLogger) -> None:
        self.driver = driver
        self.logger = logger

    @allure.step("Refresh Page")
    def refresh(self):
        self.driver.refresh()

    @allure.step("Close browser")
    def close_browser(self):
        self.driver.close()
        self.driver.quit()

    @allure.step("Attach Screenshot")
    def screenshot(self, resultMessage):
        """
        Takes screenshot of the current open web page, saves it and attaches it to the Allure report.\n
        :param resultMessage: The given message for the cause of the screenshot, the file name.\n
        """
        self.logger.info("{} - Taking and attaching a screenshot")
        res_mes = re.sub(":+", "_", resultMessage)
        curr_date = datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S")
        file_name = "{}_{}.png".format(res_mes, curr_date)
        screenshot_directory = "{}\\screenshots\\".format(get_root_dir())
        relative_file_name = "{}{}".format(screenshot_directory, file_name)
        current_directory = os.path.dirname(__file__)
        destination_file = os.path.join(current_directory, relative_file_name)
        destination_directory = os.path.join(current_directory, screenshot_directory)

        try:
            if not os.path.exists(destination_directory):
                os.makedirs(destination_directory)
            self.driver.save_screenshot(destination_file)
            self.logger.info("{} - Screenshot \"{}\" saved to directory".format(self.callers_names(), file_name))
            allure.attach.file(destination_file, attachment_type=allure.attachment_type.PNG)
            self.logger.info("{} - Screenshot \"{}\" attached to Allure report".format(self.callers_names(), file_name))
        except Exception as e:
            self.logger.error("{} - Exception Occurred when taking screenshot\n\tDirectory: \"{}\"\n\tFile: \"{}\"\n\tException: \"{}\""
                              .format(self.callers_names(), destination_directory, destination_file, e))
            print_stack()
        self.logger.info("{} - Finished taking and attaching a screenshot".format(self.callers_names()))

    @allure.step("Attach CSV file")
    def attach_csv(self, file_path, *files_paths):
        """
        Attaches a CSV file to the Allure report.\n
        :param file_path: The path to the file to attach.\n
        :param files_paths: Optional, additional paths for more CSV files to attach.\n
        """
        self.logger.info("{} - Attaching a CSV file to Allure report".format(self.callers_names()))
        try:
            allure.attach.file(source=file_path, attachment_type=allure.attachment_type.CSV)
            self.logger.info("{} - CSV file \"{}\" attached to Allure report".format(self.callers_names(), file_path))

            for path in files_paths:
                allure.attach.file(source=path, attachment_type=allure.attachment_type.CSV)
                self.logger.info("{} - CSV file \"{}\" attached to Allure report".format(self.callers_names(), path))

        except Exception as e:
            self.logger.error("{} - Exception Occurred while trying to attaching a csv file to the allure report\n\tFile: \"{}\"\n\tException: \"{}\""
                              .format(self.callers_names(), file_path, e))
            print_stack()

        self.logger.info("{} - Finished attaching a CSV file".format(self.callers_names()))

    def attach_file(self, file_path, *files_paths, file_type: allure.attachment_type):
        self.logger.info("{} - Attaching a CSV file to Allure report".format(self.callers_names()))
        try:
            allure.attach.file(source=file_path, attachment_type=file_type)
            self.logger.info("{} - CSV file \"{}\" attached to Allure report".format(self.callers_names(), file_path))

            for path in files_paths:
                allure.attach.file(source=path, attachment_type=file_type)
                self.logger.info("{} - CSV file \"{}\" attached to Allure report".format(self.callers_names(), path))

        except Exception as e:
            self.logger.error(
                "{} - Exception Occurred while trying to attaching a csv file to the allure report\n\tFile: \"{}\"\n\tException: \"{}\""
                .format(self.callers_names(), file_path, e))
            print_stack()

        self.logger.info("{} - Finished attaching a CSV file".format(self.callers_names()))

    def get_title(self):
        title = self.driver.title
        self.logger.info("{} - Getting the current tab's title: \"{}\"".format(self.callers_names(), title))
        return title

    def get_current_url(self):
        url = self.driver.current_url
        self.logger.info("{} - Getting the current tab's URL address: \"{}\"".format(self.callers_names(), url))
        return url

    def get_by_type(self, locator_type):
        self.logger.info("{} - Getting a By type: \"{}\"".format(self.callers_names(), locator_type))
        locator_type = locator_type.lower()
        if locator_type == "id":
            self.logger.info("{} - Finished getting By type, returned: \"{}\"".format(self.callers_names(), locator_type))
            return By.ID
        elif locator_type == "name":
            self.logger.info("{} - Finished getting By type, returned: \"{}\"".format(self.callers_names(), locator_type))
            return By.NAME
        elif locator_type == "tag":
            self.logger.info("{} - Finished getting By type, returned: \"{}\"".format(self.callers_names(), locator_type))
            return By.TAG_NAME
        elif locator_type == "xpath":
            self.logger.info("{} - Finished getting By type, returned: \"{}\"".format(self.callers_names(), locator_type))
            return By.XPATH
        elif locator_type == "css":
            self.logger.info("{} - Finished getting By type, returned: \"{}\"".format(self.callers_names(), locator_type))
            return By.CSS_SELECTOR
        elif locator_type == "class":
            self.logger.info("{} - Finished getting By type, returned: \"{}\"".format(self.callers_names(), locator_type))
            return By.CLASS_NAME
        elif locator_type == "link":
            self.logger.info("{} - Finished getting By type, returned: \"{}\"".format(self.callers_names(), locator_type))
            return By.LINK_TEXT
        else:
            self.logger.error("{} - Locator type \"{}\" not correct or not supported".format(self.callers_names(), locator_type))
        return False

    def wait_for_page_to_load(self, url: str, wait_time=10):
        WebDriverWait(self.driver, timeout=wait_time).until(EC.url_matches(url))
        WebDriverWait(self.driver, timeout=wait_time).until(
            lambda driver: self.driver.execute_script("return document.readyState") == "complete")

    def get_element(self, locator, locatorType="id") -> WebElement:
        """
        Get a WebElement from given arguments.\n
        :param locatorType: The locator type, default is "ID"
        :param locator: The given value of the locator
        :return: WebElement
        """
        self.logger.info("{} - Getting an element".format(self.callers_names()))
        element = None
        try:
            locator_type = locatorType.lower()
            by_type = self.get_by_type(locator_type)
            self.wait_for_element_to_appear(locator=locator, locator_type=locator_type, timeout=10)
            element = self.driver.find_element(by_type, locator)
            self.logger.info("{} - Element found with locator: \"{}\" and locatorType: \"{}\"".format(self.callers_names(), locator, locator_type))
        except Exception as e:
            self.logger.error("{} - Element not found with locator: \"{}\" and locatorType: \"{}\"\n\t\"Exception: {}\""
                              .format(self.callers_names(), locator, locatorType, e))

        return element

    def get_element_by_text(self, text) -> WebElement:
        """
        Get an element by text.\n
        :param text: The text to search.
        :return: WebElement
        """
        self.logger.info("{} - Getting an element by text: \"{}\"".format(self.callers_names(), text))
        return self.get_element("//*[text()='{}']".format(text), 'xpath')

    def get_elements_by_text(self, text) -> list:
        """
        Get a list of elements by text.\n
        :param text: The text to search.
        :return: List[WebElement]
        """
        self.logger.info("{} - Getting a list of elements by text: \"{}\"".format(self.callers_names(), text))
        return self.get_element_list("//*[text()='{}']".format(text), 'xpath')

    def get_element_by_partial_text(self, text) -> WebElement:
        """
        Get an element by partial text.\n
        :param text: The text to search.
        :return: WebElement
        """
        return self.get_element("//*[contains(text(), '{}')]".format(text), 'xpath')

    def get_elements_by_partial_text(self, text) -> list:
        """
        Get a list of elements by partial text.\n
        :param text: The text to search.
        :return: List[WebElement]
        """
        return self.get_element_list("//*[contains(text(), '{}')]".format(text), 'xpath')

    def get_element_by_text_and_tag(self, tag, text) -> WebElement:
        """
        Get an element by text for specific element tag.\n
        :param tag: The element's tag
        :param text: The text to search
        :return: WebElement
        """
        return self.get_element("//{}[text()='{}']".format(tag, text), 'xpath')

    def get_element_list(self, locator, locator_type="id") -> list:
        """
        Get list of elements
        """
        element = None
        try:
            locator_type = locator_type.lower()
            by_type = self.get_by_type(locator_type)
            self.wait_for_element_to_appear(locator=locator, locator_type=locator_type, timeout=10)
            element = self.driver.find_elements(by_type, locator)
            self.logger.info("{} - Element list found with locator: \"{}\" and locatorType: \"{}\"".format(self.callers_names(), locator, locator_type))
        except Exception as e:
            self.logger.error("{} - Element list not found with locator: \"{}\" and locatorType: \"{}\"".format(self.callers_names(), locator, locator_type))
            self.logger.error(f"raised error: {e}")
        return element

    def element_click(self, locator="", locatorType="id", element=None):
        """
        Click on an element
        """
        try:
            if len(locator) > 0:
                self.wait_for_element(locator, locatorType)
                element = self.get_element(locator, locatorType)
            element.click()
            if len(locator) > 0:
                self.logger.info("{} - Clicked on element with locator: \"{}\" and locatorType: \"{}\"".format(self.callers_names(), locator, locatorType))
            else:
                self.logger.info("{} - Clicked on element \"{}\"".format(self.callers_names(), self.text_fixer(element.text)))
            return element
        except ElementNotInteractableException:
            self.logger.error("{} - \"ElementNotIntractableException\" raised when trying to click on element with locator: \"{}\" and locatorType: \"{}\""
                              .format(self.callers_names(), locator, locatorType))
            return None
        except Exception as e:
            self.logger.error("{} - Cannot click on the element with locator: \"{}\" and locatorType: \"{}\"".format(self.callers_names(), locator,
                                                                                                                     locatorType))
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            return None

    def element_click_with_offset(self, locator="", locatorType="id", element=None, x=0, y=0):
        try:
            if len(locator) > 0:
                self.wait_for_element(locator, locatorType)
                element = self.get_element(locator, locatorType)
            action_chains = ActionChains(self.driver)
            action_chains.move_to_element_with_offset(element, x, y).click().perform()
            if len(locator) > 0:
                self.logger.info("{} - Clicked with offset [x: {} y: {}] on element with locator: \"{}\" and locatorType: \"{}\""
                                 .format(self.callers_names(), x, y, locator, locatorType))
            else:
                self.logger.info("{} - Clicked with offset [x: {} y: {}] on element \"{}\"".format(self.callers_names(), x, y, self.text_fixer(element.text)))
            return element
        except ElementNotInteractableException:
            self.logger.error(
                "{} - \"ElementNotIntractableException\" raised when trying to click with offset on element with locator: \"{}\" and locatorType: \"{}\""
                .format(self.callers_names(), locator, locatorType))
            return None
        except Exception as e:
            self.logger.error("{} - \"{}\" raised when trying to click with offset on the element with locator: \"{}\" and locatorType: \"{}\""
                              .format(self.callers_names(), e.__name__, locator, locatorType))
            print_stack()
            return None

    def element_right_click_with_offset(self, locator="", locatorType="id", element=None, x=0, y=0):
        try:
            if len(locator) > 0:
                self.wait_for_element(locator, locatorType)
                element = self.get_element(locator, locatorType)
            action_chains = ActionChains(self.driver)
            action_chains.move_to_element_with_offset(element, x, y).context_click(element).perform()
            if len(locator) > 0:
                self.logger.info("{} - Right clicked with offset [x: {} y: {}] on element with locator: \"{}\" and locatorType: \"{}\""
                                 .format(self.callers_names(), x, y, locator, locatorType))
            else:
                self.logger.info(
                    "{} - Right clicked with offset [x: {} y: {}] on element \"{}\"".format(self.callers_names(), x, y, self.text_fixer(element.text)))
            return element
        except ElementNotInteractableException:
            self.logger.error(
                "{} - \"ElementNotIntractableException\" raised when trying to right click with offset on element with locator: \"{}\" and locatorType: \"{}\""
                .format(self.callers_names(), locator, locatorType))
            return None
        except Exception as e:
            self.logger.error("{} - Cannot right click with offset on the element with locator: \"{}\" and locatorType: \"{}\""
                              .format(self.callers_names(), locator, locatorType))
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            print_stack()
            return None

    def element_right_click(self, locator="", locatorType="id", element=None):
        """
        Right-click on an element
        """
        try:
            if len(locator) > 0:
                self.wait_for_element(locator, locatorType)
                element = self.get_element(locator, locatorType)

            action_chains = ActionChains(self.driver)
            action_chains.context_click(element).perform()

            if len(locator) > 0:
                self.logger.info("{} - Right clicked on element with locator: \"{}\" and locatorType: \"{}\""
                                 .format(self.callers_names(), locator, locatorType))
            else:
                self.logger.info("{} - Right clicked on element \"{}\"".format(self.callers_names(), self.text_fixer(element.text)))

        except Exception as e:
            self.logger.error("{} - Cannot right click on the element with locator: \"{}\" and locatorType: \"{}\""
                              .format(self.callers_names(), locator, locatorType))
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            print_stack()

    def element_double_click(self, locator="", locatorType="id", element=None):
        """
        Double-click on an element
        """
        try:
            if len(locator) > 0:
                self.wait_for_element(locator, locatorType)
                element = self.get_element(locator, locatorType)
            action_chain = ActionChains(self.driver)
            action_chain.double_click(element).perform()

            if len(locator) > 0:
                self.logger.info("{} - Double clicked on element with locator: \"{}\" and locatorType: \"{}\"".format(self.callers_names(), locator,
                                                                                                                      locatorType))
            else:
                self.logger.info("{} - Double clicked on element \"{}\"".format(self.callers_names(), self.text_fixer(element.text)))

        except Exception as e:
            self.logger.error("{} - Cannot double click on the element with locator: \"{}\" and locatorType: \"{}\"".format(self.callers_names(), locator,
                                                                                                                            locatorType))
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            print_stack()

    def send_keys(self, data, locator="", locatorType="id", element=None):
        """
        Send keys to an element
        """
        try:
            if len(locator) > 0:
                element = self.get_element(locator, locatorType)
            element.send_keys(data)

            if len(locator) > 0:
                self.logger.info("{} - Sent data to element with locator: \"{}\" and locatorType: \"{}\"".format(self.callers_names(), locator, locatorType))
            else:
                self.logger.info("{} - Sent data to element \"{}\"".format(self.callers_names(), self.text_fixer(element.text)))

        except Exception as e:
            if len(locator) > 0:
                self.logger.error("{} - Cannot send data to element with locator: \"{}\" and locatorType: \"{}\""
                                  .format(self.callers_names(), locator, locatorType))
            else:
                self.logger.error("{} - Cannot send data to element \"{}\"".format(self.callers_names(), self.text_fixer(element.text)))
                self.logger.error(f"{self.callers_names()} :raised error: {e}")
            print_stack()

    def clear_input_field(self, locator="", locatorType="id", element: WebElement = None):
        """
        Clears an input field
        """
        if element is None:
            element = self.get_element(locator, locatorType)

        element.clear()

        if len(locator) > 0:
            self.logger.info("{} - Cleared field for element with locator: \"{}\" and locatorType: \"{}\"".format(self.callers_names(), locator, locatorType))
        else:
            self.logger.info("{} - Cleared field for element \"{}\"".format(self.callers_names(), self.text_fixer(element.text)))

    def get_console_logs(self, messageQualifier=''):
        ret_val = ''
        for entry in self.driver.get_log('browser'):
            if messageQualifier in entry['message']:
                ret_val += entry['message'] + '\n'
        return ret_val

    def get_text(self, locator="", locatorType="id", element=None):
        """
        Get a WebElement's text.\n
        """
        try:
            if len(locator) > 0:
                self.wait_for_element(locator, locatorType)
                element = self.get_element(locator, locatorType)
            text = element.text

            if len(text) == 0:
                text = element.get_attribute("innerText")

            if len(text) != 0:
                text = re.sub("\n", " ", text.strip())
                if len(locator) > 0:
                    self.logger.info("{} - Getting text on element with locator: \"{}\" and locatorType: \"{}\"".format(self.callers_names(), locator,
                                                                                                                        locatorType))
                self.logger.info("{} - The text is '{}'".format(self.callers_names(), text))
        except Exception as e:
            if len(locator) > 0:
                self.logger.error("{} - Failed to get text on element with locator: \"{}\" and locatorType: \"{}\""
                                  .format(self.callers_names(), locator, locatorType))
            else:
                self.logger.error("{} - Failed to get text on element")
            print_stack()
            text = None
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
        return text

    def get_css_value(self, locator="", locatorType="id", cssProperty="", element=None):
        """
        Get a WebElement's CSS attribute value.\n
        """
        try:
            css_attribute = ""
            attribute = ""
            if len(locator) > 0:
                if element is None:
                    element = self.get_element(locator, locatorType)
                css_attribute = element.value_of_css_property(cssProperty)
            if len(css_attribute) != 0:
                if len(locator) > 0:
                    self.logger.info("{} - Getting CSS value of property \"{}\" from element with locator: \"{}\" and locatorType: \"{}\""
                                     .format(self.callers_names(), cssProperty, locator, locatorType))
                else:
                    self.logger.info("{} - Getting CSS value of property \"{}\" from element \"{}\"".format(self.callers_names(), cssProperty,
                                                                                                            self.text_fixer(element.text)))
                self.logger.info("{} - The value of property \"{}\" is \"{}\"".format(self.callers_names(), cssProperty, css_attribute))
                attribute = css_attribute.strip()
        except Exception as e:
            if len(locator) > 0:
                self.logger.error("{} - Failed to get CSS value of property \"{}\" from element with locator: \"{}\" and locatorType: \"{}\""
                                  .format(self.callers_names(), cssProperty, locator, locatorType))
            else:
                self.logger.error("{} - Failed to get CSS value of property \"{}\" from element \"{}\"".format(self.callers_names(), cssProperty,
                                                                                                               self.text_fixer(element.text)))
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            print_stack()
            attribute = None
        return attribute

    def get_css_value_for_element(self, element, cssProperty):
        """
        Get a WebElement's CSS attribute value.\n
        """
        try:
            attribute = ""
            css_attribute = element.value_of_css_property(cssProperty)
            if len(css_attribute) != 0:
                self.logger.info(
                    "{} - Getting CSS value of property \"{}\" from element \"{}\"".format(self.callers_names(), cssProperty, self.text_fixer(element.text)))
                self.logger.info("{} - The value of property \"{}\" is \"{}\"".format(self.callers_names(), cssProperty, css_attribute))
                attribute = css_attribute.strip()
        except Exception as e:
            self.logger.error(
                "{} - Failed to get CSS value of property \"{}\" from element \"{}\"".format(self.callers_names(), cssProperty, self.text_fixer(element.text)))
            print_stack()
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            attribute = None
        return attribute

    def get_attribute(self, locator="", locatorType="id", attribute="", element=None):
        """
        Get a WebElement's attribute value.\n
        """
        try:
            if len(locator) > 0:
                self.wait_for_element(locator, locatorType)
                element = self.get_element(locator, locatorType)
            att = element.get_attribute(attribute)

            if len(att) != 0:
                if len(locator) > 0:
                    self.logger.info("{} - Getting value of attribute \"{}\" from element with locator: \"{}\" and locatorType: \"{}\""
                                     .format(self.callers_names(), attribute, locator, locatorType))
                else:
                    self.logger.info(
                        "{} - Getting value of attribute \"{}\" from element \"{}\"".format(self.callers_names(), attribute, self.text_fixer(element.text)))
                self.logger.info("{} - The value of attribute \"{}\" is \"{}\"".format(self.callers_names(), attribute, att.replace("\n", " ")))
            att = att.strip()
        except Exception as e:
            if len(locator) > 0:
                self.logger.error("{} - Failed to get value of attribute \"{}\" from element with locator: \"{}\" and locatorType: \"{}\""
                                  .format(self.callers_names(), attribute, locator, locatorType))
            else:
                self.logger.error(
                    "{} - Failed to get value of attribute \"{}\" from element \"{}\"".format(self.callers_names(), attribute, self.text_fixer(element.text)))
            print_stack()
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            att = None
        return att

    def get_attribute_for_element(self, element, attribute):
        """
        Get a WebElement's attribute value.\n
        """
        try:
            res_attribute = element.get_attribute(attribute)
            if len(attribute) != 0:
                self.logger.info(
                    "{} - Getting value of attribute \"{}\" from element \"{}\"".format(self.callers_names(), res_attribute, self.text_fixer(element.text)))
                self.logger.info("{} - The value of attribute \"{}\" is \"{}\"".format(self.callers_names(), attribute, res_attribute))
            res_attribute = res_attribute.strip()
        except Exception as e:
            self.logger.error(
                "{} - Failed to get value of attribute \"{}\" from element \"{}\"".format(self.callers_names(), attribute, self.text_fixer(element.text)))
            print_stack()
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            res_attribute = None
        return res_attribute

    def is_element_present(self, locator="", locatorType="id", element=None):
        """
        Check if element is present.\n
        """
        try:
            if len(locator) > 0:
                element = self.get_element(locator, locatorType)
            if element is not None:
                self.logger.info("{} - Element present with locator: \"{}\" locatorType: \"{}\"".format(self.callers_names(), locator, locatorType))
                return True
            else:
                self.logger.error("{} - Element not present with locator: \"{}\" locatorType: \"{}\"".format(self.callers_names(), locator, locatorType))
                return False
        except Exception as e:
            self.logger.error("{} - Element not found")
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            return False

    def is_element_displayed(self, locator="", locatorType="id", element=None):
        """
        Check if element is displayed.\n
        """
        is_displayed = False
        try:
            if len(locator) > 0:
                element = self.get_element(locator, locatorType)
            if element is not None:
                is_displayed = element.is_displayed()
                self.logger.info("{} - Element is displayed".format(self.callers_names()))
            else:
                self.logger.error("{} - Element not displayed".format(self.callers_names()))
            return is_displayed
        except Exception as e:
            print("Element not found")
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            return False

    def is_element_enabled(self, locator="", locatorType="id", element=None):
        """
        Check if element is enabled.\n
        """
        is_enabled = False
        try:
            if len(locator) > 0:
                element = self.get_element(locator, locatorType)
            if element is not None:
                is_enabled = element.is_enabled()
                self.logger.info("{} - Element is enabled")
            else:
                self.logger.info("{} - Element not enabled")
            return is_enabled
        except Exception as e:
            print("Element not found")
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            return False

    def element_presence_check(self, locator="", locatorType="id"):
        """
        Check if element is present.\n
        """
        try:
            element_list = self.driver.find_elements(locatorType, locator)
            if len(element_list) > 0:
                self.logger.info("{} - Element present with locator: {} and locatorType: {}".format(self.callers_names(), locator, locatorType))
                return True
            else:
                self.logger.info("{} - Element not present with locator: {} and locatorType: {}".format(self.callers_names(), locator, locatorType))
                return False
        except Exception as e:
            self.logger.info("{} - Element not found")
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            return False

    def wait_for_element_to_be_gone(self, locator=None, locator_type='id', timeout=10, poll_frequency=0.5, element=None):
        try:
            if element is None:
                loc_type = self.get_by_type(locator_type)
                self.logger.info("{} - Waiting for maximum {} seconds for element to be clickable".format(self.callers_names(), str(timeout)))
                wait = WebDriverWait(self.driver, timeout=timeout, poll_frequency=poll_frequency,
                                     ignored_exceptions=[NoSuchElementException, ElementNotVisibleException, ElementNotSelectableException])
                element = wait.until(EC.invisibility_of_element((loc_type, locator)))
                self.logger.info("{} - Element appeared on the web page".format(self.callers_names()))
            else:
                self.logger.info(
                    "{} - Waiting for maximum {} seconds for element to be clickable".format(self.callers_names(),
                                                                                             str(timeout)))
                wait = WebDriverWait(self.driver, timeout=timeout, poll_frequency=poll_frequency,
                                     ignored_exceptions=[NoSuchElementException, ElementNotVisibleException,
                                                         ElementNotSelectableException])
                element = wait.until(EC.invisibility_of_element(element))
                self.logger.info("{} - Element appeared on the web page".format(self.callers_names()))
        except Exception as e:
            self.logger.error("{} - Element not appeared on the web page".format(self.callers_names()))
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            print_stack()
        finally:
            return element

    def wait_for_stateless_element(self, element, wait_time=10):
        staleness = False
        try:
            wait = WebDriverWait(self.driver, timeout=wait_time, poll_frequency=0.5,
                                 ignored_exceptions=[NoSuchElementException, ElementNotVisibleException,
                                                     ElementNotSelectableException])
            staleness = wait.until(EC.staleness_of(element))
            self.logger.info("{} - Element is staleness on the web page".format(self.callers_names()))
        except Exception as e:
            self.logger.error("{} - Element not staleness on the web page".format(self.callers_names()))
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            print_stack()
        finally:
            return staleness

    def wait_for_text_change(self, text, locator, locator_type="id", timeout=10, to=False):
        """
        Waits for text to change in element.\n
        :param text: the current text in the element to wait for it to change
        :param locator: the locator of whom to find the element
        :param locator_type: the locator loc_type
        :param timeout: the wait time for the change
        :param to: an indicator - mark false to wait for the current text to change. mark true to wait for a specific text to appear
        :return: the element
        """
        element = None
        try:
            loc_type = self.get_by_type(locator_type)
            wait = WebDriverWait(self.driver, timeout, 0.5,
                                 ignored_exceptions=[NoSuchElementException, ElementNotVisibleException, ElementNotSelectableException])
            condition = EC.text_to_be_present_in_element((loc_type, locator), text)
            if not to:
                element = wait.until_not(condition)
            else:
                element = wait.until(condition)
        except Exception as e:
            print_stack()
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
        finally:
            return element

    def wait_for_element_to_disappear(self, locator, locator_type="id", timeout=10, poll_frequency=0.5):
        element = None
        try:
            loc_type = self.get_by_type(locator_type)
            self.logger.info("{} - Waiting for maximum {} seconds for element to disappear".format(self.callers_names(), str(timeout)))
            wait = WebDriverWait(self.driver, timeout=timeout, poll_frequency=poll_frequency,
                                 ignored_exceptions=[NoSuchElementException, ElementNotVisibleException, ElementNotSelectableException])
            element = wait.until_not(EC.presence_of_element_located((loc_type, locator)))
            self.logger.info("{} - Element with locator: \"{}\" and locatorType: \"{}\" disappeared from the web page".format(self.callers_names(), locator,
                                                                                                                              locator_type))
        except Exception as e:
            self.logger.error("{} - Element with locator: \"{}\" and locatorType: \"{}\" did not disappear from the web page"
                              .format(self.callers_names(), locator, locator_type))
            print_stack()
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            return None
        finally:
            return element

    def wait_for_element_to_appear(self, locator, locator_type="id", timeout=10, poll_frequency=0.5):
        element = None
        try:
            loc_type = self.get_by_type(locator_type)
            self.logger.info("{} - Waiting for maximum {} seconds for element to appear".format(self.callers_names(), str(timeout)))
            wait = WebDriverWait(self.driver, timeout=timeout, poll_frequency=poll_frequency,
                                 ignored_exceptions=[NoSuchElementException, ElementNotVisibleException, ElementNotSelectableException])
            element = wait.until(EC.presence_of_element_located((loc_type, locator)))
            self.logger.info("{} - Element with locator: \"{}\" and locatorType: \"{}\" appeared on the web page".format(self.callers_names(), locator,
                                                                                                                         locator_type))
        except Exception as e:
            self.logger.error("{} - Element with locator: \"{}\" and locatorType: \"{}\" did not appear on the web page"
                              .format(self.callers_names(), locator, locator_type))
            print_stack()
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
        finally:
            return element

    def wait_for_text_in_element(self, locator, text, locator_type="id", timeout=10, poll_frequency=0.5):
        element = None
        try:
            loc_type = self.get_by_type(locator_type)
            self.logger.info("{} - Waiting for maximum {} seconds for element to be clickable".format(self.callers_names(), str(timeout)))
            wait = WebDriverWait(self.driver, timeout=timeout, poll_frequency=poll_frequency,
                                 ignored_exceptions=[NoSuchElementException, ElementNotVisibleException, ElementNotSelectableException])
            element = wait.until(EC.text_to_be_present_in_element((loc_type, locator), text))
            self.logger.info("{} - Element appeared on the web page".format(self.callers_names()))
        except Exception as e:
            self.logger.error("{} - Element not appeared on the web page")
            print_stack()
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
        finally:
            return element

    def wait_for_element(self, locator, locatorType="id", timeout=10, pollFrequency=0.5):
        element = None
        try:
            by_type = self.get_by_type(locatorType)
            self.logger.info("{} - Waiting for maximum {} seconds for element to be clickable".format(self.callers_names(), str(timeout)))
            wait = WebDriverWait(self.driver, timeout=timeout, poll_frequency=pollFrequency,
                                 ignored_exceptions=[NoSuchElementException, ElementNotVisibleException, ElementNotSelectableException])
            element = wait.until(EC.element_to_be_clickable((by_type, locator)))
            self.logger.info("{} - Element appeared on the web page".format(self.callers_names()))
        except Exception as e:
            self.logger.error("{} - Element not appeared on the web page")
            print_stack()
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
        return element

    def get_parent_element(self, locator="", locatorType="id", element: WebElement = None):
        """
        Get element's parent
        """
        parent = None
        try:
            if len(locator) > 0:
                element = self.get_element(locator, locatorType)
            parent = element.parent
        except Exception as e:
            self.logger.error("{} - Element not found with locator: {} and locatorType: {}".format(self.callers_names(), locator, locatorType))
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
        return parent

    def get_element_parent_special(self, att_val: str):
        return self.driver.find_element(By.XPATH, "//*[@data-test-e2e='{}']/..".format(att_val))

    def get_elements_parent(self, element):
        """
        Get element's parent
        """
        parent = None
        try:
            parent = element.find_element_by_xpath('..')
        except Exception as e:
            self.logger.error("{} - Failed to get element's parent.")
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
        return parent

    def get_child_element(self, element=None, locator="", locatorType="id"):
        """
        Please don't use this!!!\n
        Find element's child by locator
        """
        child = None
        try:
            by_type = self.get_by_type(locatorType)
            child = SeleniumDriver(element, self.logger).get_element(locator, by_type)
        except Exception as e:
            self.logger.error("{} - Element not found with locator: {} and locatorType: {}".format(self.callers_names(), locator, locatorType))
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
        return child

    def mouse_hover(self, locator="", locatorType="id", element=None):
        """
        Hover on an element
        """
        try:
            if len(locator) > 0:
                self.wait_for_element(locator, locatorType)
                element = self.get_element(locator, locatorType)
            hover = ActionChains(self.driver).move_to_element(element)
            hover.perform()
            self.logger.info("{} - Hovered on element with locator: {} and locatorType: {}".format(self.callers_names(), locator, locatorType))
        except Exception as e:
            self.logger.error("{} - Cannot hover on the element with locator: {} and locatorType: {}".format(self.callers_names(), locator, locatorType))
            self.logger.error(f"{self.callers_names()} :raised error: {e}")
            print_stack()

    def web_scroll(self, direction="up"):
        """
        Scrolls the web page
        """
        if direction == "up":
            # Scroll Up
            self.driver.execute_script("window.scrollBy(0, -1000);")

        if direction == "down":
            # Scroll Down
            self.driver.execute_script("window.scrollBy(0, 1000);")

    def drag_by_offset(self, element, x_offset, y_offset):
        action_chain = ActionChains(self.driver)
        action_chain.drag_and_drop_by_offset(element, x_offset, y_offset)
        action_chain.perform()

    def double_click_on_location(self, element, x_offset, y_offset):
        action = ActionChains(self.driver)
        action.move_to_element_with_offset(to_element=element, xoffset=x_offset,
                                           yoffset=y_offset).double_click().perform()

    def right_click_on_location(self, elem, x_offset, y_offset):
        action = ActionChains(self.driver)
        action.move_to_element_with_offset(to_element=elem, xoffset=x_offset,
                                           yoffset=y_offset).context_click().perform()

    def move_mouse_by_offset(self, x_point, y_point):
        action = ActionChains(self.driver)
        action.move_by_offset(x_point, y_point).perform()

    def drag_mouse(self, x_start, y_start, x_end, y_end, drag_duration):
        mouse.drag(x_start, y_start, x_end, y_end, True, drag_duration)

    def click_at_coordinates_with_mouse(self, x, y):
        mouse.move(x, y, True, 0)
        mouse.click("left")

    def scroll_with_mouse(self, direction: int):
        mouse.wheel(direction)

    def move_mouse_pointer(self, x, y, movement_duration):
        mouse.move(x, y, True, movement_duration)

    def mouse_click(self, button_to_click):
        mouse.click(button_to_click)

    def mouse_press(self, button_to_press):
        mouse.press(button_to_press)

    def mouse_release(self, button_to_release):
        mouse.release(button_to_release)

    def mouse_position(self):
        return mouse.get_position()

    def zoom_on_location(self, x, y, direction):
        self.move_mouse_pointer(x, y, 1)
        self.scroll_with_mouse(direction)

    def click_on_list_label(self, item_id):
        item_id = f'"{item_id}"'
        path = "//label[@for=" + item_id + "]"
        self.element_click(locator=path, locatorType=self.get_by_type("xpath"))

    def get_canvas_data(self):
        html = self.get_element("html", "tag")
        inner_width = int(html.get_attribute("clientWidth"))
        inner_height = int(html.get_attribute("clientHeight"))
        self.logger.info("{} - inner_width: {}, inner_height: {}".format(self.callers_names(), inner_width, inner_height))
        return inner_width, inner_height

    def double_click_graphic_element(self, x, y):
        html_element = self.get_element("html", "tag")
        self.double_click_on_location(html_element, x, y)
        self.logger.info("{} - end of double_click_graphic_element")

    def right_click_graphic_element(self, x, y):
        html_element = self.get_element("html", "tag")
        self.right_click_on_location(html_element, x, y)
        self.logger.info("{} - end of right_click_graphic_element")
        self.right_click_on_location(html_element, x + 5, y + 5)

    def move_to_element(self, element):
        action = ActionChains(self.driver)
        action.move_to_element(element).perform()

    def check_checkbox(self, element, check: bool):
        if check:
            if not element.is_selected():
                self.logger.info("Checking a checkbox")
                self.element_click_js(element=element)
        else:
            if element.is_selected():
                self.element_click_js(element=element)

    def get_elements_list_special_attribute(self, att_val: str):
        """
        Get Elements list by using XPATH with the 'data-test-e2e' attribute.\n
        Send optional parent element for element with a non-unique value\n
        :param att_val: the attribute value.
        :return: requested WebElement.
        """
        return self.get_element_list("//*[@data-test-e2e='{}']".format(att_val), "xpath")

    def get_elements_list_containing_special_attribute_and_tag(self, tag: str, att_val: str):
        """
        Get Elements list by tag and the 'data-test-e2e' attribute.\n
        Send optional parent element for element with a non unique value\n
        :param tag: the
        :param att_val: the attribute value.
        :return: requested WebElement.
        """
        return self.get_element_list("//{}[contains(@data-test-e2e, '{}')]".format(tag, att_val), "xpath")

    def get_elements_list_containing_special_attribute(self, att_val: str):
        """
        Get Elements list containing a partial 'data-test-e2e' attribute.\n
        Send optional parent element for element with a non unique value\n
        :param att_val: the attribute value.
        :return: requested WebElement.
        """
        self.wait_for_element(locator="//*[contains(@data-test-e2e, '{}')]".format(att_val), locatorType="xpath", timeout=10)
        return self.driver.find_elements(By.XPATH, "//*[contains(@data-test-e2e, '{}')]".format(att_val))

    def get_element_with_special_attribute(self, att_val: str, parent: we = None):
        """
        Get Element by using XPATH with the 'data-test-e2e' attribute.\n
        Send optional parent element for element with a non unique value\n
        :param att_val: the attribute value.
        :param parent: optional parent element.
        :return: requested WebElement.
        """
        try:
            if parent is None:
                return self.get_element("//*[@data-test-e2e='{}']".format(att_val), "xpath")
            else:
                return self.get_element_from_element(parent_element=parent, locator="[data-test-e2e='{}']".format(att_val), locator_type="css")
                # return parent.find_element(By.CSS_SELECTOR, "[data-test-e2e='{}']".format(att_val))
        except Exception as e:
            self.logger.error(f"raised error: {e}")
            return None

    def get_element_with_special_attribute_string(self, att_val: str, parent: str = None):
        """
                Get Element by using XPATH with the 'data-test-e2e' attribute.\n
                Send optional parent 'data-test-e2e' attribute value for element with a non unique value\n
                :param att_val: the attribute value.
                :param parent: optional parent attribute value.
                :return: requested WebElement.
                """
        if parent is None:
            return self.get_element(locator="//*[@data-test-e2e='{}']".format(att_val), locatorType="xpath")
            # return self.driver.find_element(By.XPATH, "//*[@data-test-e2e='{}']".format(att_val))
        else:
            return self.get_element(locator="//*[@data-test-e2e='{}']//*[@data-test-e2e='{}']".format(parent, att_val), locatorType="xpath")
            # return self.driver.find_element(By.XPATH, "//*[@data-test-e2e='{}']//*[@data-test-e2e='{}']".format(parent, att_val))

    def get_element_from_element(self, parent_element, locator, locator_type):
        element = None
        try:
            element = parent_element.find_element(self.get_by_type(locator_type), locator)
        except Exception as e:
            self.logger.error("{} - Element not found".format(self.callers_names()))
            self.logger.error(f"raised error: {e}")
        return element

    def get_element_list_from_element(self, parent_element, locator, locator_type):
        return parent_element.find_elements(self.get_by_type(locator_type), locator)

    def element_click_js(self, locator="", locator_type="", element=None):
        if element is None:
            self.driver.execute_script("arguments[0].click();", self.get_element(locator, self.get_by_type(locator_type)))
        else:
            self.driver.execute_script("arguments[0].click();", element)

    def wait_attribute_change(self, element, attribute, desired_value, max_wait_time):
        if element is None:
            return None
        waiting = 0
        sleep_interval = 1
        while str(element.get_attribute(attribute)) != str(desired_value):
            time.sleep(sleep_interval)
            waiting = waiting + sleep_interval
            if waiting >= max_wait_time:
                if str(element.get_attribute(attribute)) == str(desired_value):
                    return element
                return None
        return element

    def wait(self, num_of_seconds):
        time.sleep(num_of_seconds)

    def callers_names(self) -> str:
        """
        Returns the caller class and method names.\n
        """
        inspector = inspect.stack()[1][0]
        caller_class = inspector.f_locals["self"].__class__.__name__
        caller_method = inspector.f_code.co_name
        caller_line = inspect.currentframe().f_back.f_lineno
        return "{}::{}::{}".format(caller_class, caller_method, caller_line)

    def text_fixer(self, text: str) -> str:
        res = re.sub("\n", " ", text)
        res = re.sub(r"[^\w\s.,(){}\[\]\-]", "", res)
        return res
