from selenium.webdriver.support.events import EventFiringWebDriver, AbstractEventListener


class EventListener(AbstractEventListener):

    def __init__(self):
        self.sd = None

    def set_sd(self, sd):
        self.sd = sd

    def on_exception(self, exception, driver):
        self.sd.screenshot("exception")
        # print(exception)
        